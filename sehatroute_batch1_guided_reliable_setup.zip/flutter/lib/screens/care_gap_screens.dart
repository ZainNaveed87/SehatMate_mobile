import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_routes.dart';
import '../core/app_theme.dart';
import '../data/demo_data.dart';
import '../services/auth_service.dart';
import '../services/care_plan_service.dart';
import '../widgets/app_shell.dart';
import '../widgets/care_setup_progress.dart';
import '../widgets/page_header.dart';
import '../widgets/status_badge.dart';
import '../widgets/ui.dart';

Future<void> _navigateToGapAction(
  BuildContext context,
  CareGapItemData gap,
) async {
  final planId = gap.targetCarePlanId.isNotEmpty
      ? gap.targetCarePlanId
      : gap.carePlanId;

  switch (gap.actionType) {
    case 'review_instruction':
      await Navigator.pushNamed(
        context,
        AppRoutes.carePlanReview,
        arguments: CarePlanReviewArgs(planId: planId, returnToPrevious: true),
      );
      return;
    case 'review_schedule':
      await Navigator.pushNamed(
        context,
        AppRoutes.carePlan(planId),
        arguments: CarePlanDetailArgs(initialTab: gap.targetCarePlanTab ?? 1, returnToPrevious: true),
      );
      return;
    case 'reality_check':
      await Navigator.pushNamed(
        context,
        AppRoutes.realityCheck,
        arguments: CareFlowArgs(planId: planId, returnToPrevious: true),
      );
      return;
    case 'documents':
      await Navigator.pushNamed(
        context,
        AppRoutes.carePlanUpload,
        arguments: CarePlanUploadArgs(
          planId: planId,
          documentTypes: const [],
          returnToPrevious: true,
        ),
      );
      return;
    case 'family_care':
      await Navigator.pushNamed(context, AppRoutes.family);
      return;
    case 'calendar':
      await Navigator.pushNamed(context, AppRoutes.calendar);
      return;
    case 'care_plan':
    default:
      await Navigator.pushNamed(
        context,
        AppRoutes.carePlan(planId),
        arguments: CarePlanDetailArgs(initialTab: gap.targetCarePlanTab ?? 0, returnToPrevious: true),
      );
  }
}

class CareGapsScreen extends StatefulWidget {
  const CareGapsScreen({
    super.key,
    this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String? planId;
  final bool guidedSetup;
  final bool returnToPrevious;

  @override
  State<CareGapsScreen> createState() => _CareGapsScreenState();
}

class _CareGapsScreenState extends State<CareGapsScreen> {
  String filter = 'All';
  static const filters = [
    'All',
    'Blocking',
    'Needs attention',
    'In Progress',
  ];

  bool loading = true;
  String? error;
  List<CareGapItemData> gaps = const [];
  Map<String, String> planTitles = const {};

  @override
  void initState() {
    super.initState();
    if (AuthSession.instance.isGuest) {
      loading = false;
    } else {
      _load();
    }
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (AuthSession.instance.isGuest) return;
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }

    try {
      final plans = await CarePlanService.instance.fetchPlans();
      final scopedPlans = widget.planId == null
          ? plans
          : plans.where((plan) => plan.id == widget.planId).toList();
      final results = await Future.wait(
        scopedPlans.map(
          (plan) => forceRefresh
              ? CarePlanService.instance.refreshCareGaps(plan.id)
              : CarePlanService.instance.fetchCareGaps(plan.id),
        ),
      );

      if (!mounted) return;
      setState(() {
        planTitles = {for (final plan in scopedPlans) plan.id: plan.title};
        gaps = results.expand((result) => result.gaps).toList()
          ..sort((a, b) {
            if (a.isResolved != b.isResolved) return a.isResolved ? 1 : -1;
            if (a.blocking != b.blocking) return a.blocking ? -1 : 1;
            return a.title.toLowerCase().compareTo(b.title.toLowerCase());
          });
        loading = false;
      });
    } on CarePlanException catch (exception) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = exception.message;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'Care gaps could not be loaded.';
      });
    }
  }

  List<CareGapItemData> get visibleGaps => switch (filter) {
        'Blocking' => gaps.where((gap) => gap.blocking && !gap.isResolved).toList(),
        'Needs attention' => gaps
            .where(
              (gap) =>
                  !gap.isResolved &&
                  gap.severity == 'attention' &&
                  !gap.isInProgress,
            )
            .toList(),
        'In Progress' => gaps.where((gap) => gap.isInProgress).toList(),
        _ => gaps.where((gap) => !gap.isResolved).toList(),
      };

  @override
  Widget build(BuildContext context) {
    if (AuthSession.instance.isGuest) return _guestScreen();

    final openCount = gaps.where((gap) => !gap.isResolved).length;
    final blockingCount = gaps.where((gap) => gap.blocking && !gap.isResolved).length;
    return AppShell(
      currentRoute: AppRoutes.careGaps,
      title: 'Care Gaps',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.guidedSetup && widget.planId != null)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () {
                  if (widget.returnToPrevious && Navigator.canPop(context)) {
                    Navigator.pop(context);
                    return;
                  }
                  Navigator.pushReplacementNamed(
                    context,
                    AppRoutes.simulation,
                    arguments: CareFlowArgs(
                      planId: widget.planId!,
                      guidedSetup: true,
                    ),
                  );
                },
                icon: const Icon(Icons.arrow_back, size: 17),
                label: Text(
                  widget.returnToPrevious ? 'Back' : 'Back to Simulation',
                ),
              ),
            ),
          PageHeader(
            title: 'Care Gaps',
            subtitle: loading
                ? 'Checking your care plans for missing or unresolved items.'
                : '$openCount open · $blockingCount blocking',
            action: OutlinedButton.icon(
              onPressed: loading ? null : () => _load(forceRefresh: true),
              icon: const Icon(Icons.refresh, size: 17),
              label: const Text('Refresh'),
            ),
          ),
          if (widget.guidedSetup && widget.planId != null) ...[
            GuidedCareSetupProgress(
              currentStep: 6,
              planId: widget.planId!,
              saveState: loading ? 'Saving…' : 'Saved',
            ),
            const SizedBox(height: 16),
          ],
          if (error != null) ...[
            SafetyNote(text: error!),
            const SizedBox(height: 16),
          ],
          _filterBar(),
          const SizedBox(height: 20),
          if (loading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 48),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (visibleGaps.isEmpty)
            const EmptyState(
              icon: Icons.shield_outlined,
              title: 'Everything currently looks ready',
              description: 'No care gaps match this filter right now.',
            )
          else
            ...visibleGaps.map(_gapCard),
          if (widget.guidedSetup &&
              !widget.returnToPrevious &&
              widget.planId != null) ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: blockingCount > 0 ? null : _continueToFinalSimulation,
                icon: const Icon(Icons.refresh, size: 17),
                label: Text(
                  blockingCount > 0
                      ? 'Resolve required blockers first'
                      : 'Run Final Simulation',
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          const SafetyNote(
            text:
                'Care gaps highlight missing or unresolved care-plan steps. They do not diagnose medical risk or change treatment.',
          ),
        ],
      ),
    );
  }

  Future<void> _continueToFinalSimulation() async {
    final planId = widget.planId;
    if (planId == null) return;
    try {
      await CarePlanService.instance.updateSetupStep(
        planId,
        CareSetupStep.activate,
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.simulation,
        arguments: CareFlowArgs(planId: planId, guidedSetup: true),
      );
    } on CarePlanException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    }
  }

  Widget _filterBar() => Wrap(
        spacing: 8,
        runSpacing: 8,
        children: filters.map((value) {
          final active = value == filter;
          return InkWell(
            onTap: () => setState(() => filter = value),
            borderRadius: BorderRadius.circular(99),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: active ? AppColors.primaryLight : AppColors.card,
                border: Border.all(
                  color: active ? AppColors.primary : AppColors.border,
                ),
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: active ? AppColors.accentForeground : AppColors.muted,
                ),
              ),
            ),
          );
        }).toList(),
      );

  Widget _gapCard(CareGapItemData gap) {
    final planTitle = planTitles[gap.carePlanId] ?? 'Care Plan';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: FadeSlideIn(
        child: AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  StatusBadge(status: gap.badgeStatus),
                  _smallBadge(
                    gap.severityLabel,
                    gap.severityWasBlocking
                        ? AppColors.criticalSoft
                        : AppColors.warningSoft,
                    gap.severityWasBlocking
                        ? AppColors.criticalForeground
                        : AppColors.warningForeground,
                  ),
                  if (!gap.isResolved)
                    _smallBadge(
                      gap.lifecycleLabel,
                      AppColors.infoSoft,
                      AppColors.infoForeground,
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                gap.title,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 3),
              Text(
                '${gap.typeLabel} · $planTitle',
                style: const TextStyle(fontSize: 13, color: AppColors.muted),
              ),
              if (gap.whenText.isNotEmpty) ...[
                const SizedBox(height: 3),
                Text(
                  gap.whenText,
                  style: const TextStyle(fontSize: 13, color: AppColors.muted),
                ),
              ],
              const SizedBox(height: 9),
              Text(
                gap.summary,
                style: const TextStyle(fontSize: 14, color: AppColors.muted),
              ),
              if (gap.reason.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  'Why: ${gap.reason}',
                  style: const TextStyle(fontSize: 14),
                ),
              ],
              if (!gap.isResolved && gap.nextStep.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  'Next step: ${gap.nextStep}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.accentForeground,
                  ),
                ),
              ],
              const SizedBox(height: 15),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton(
                    onPressed: () async {
                      await Navigator.pushNamed(context, AppRoutes.careGap(gap.id));
                      if (mounted) await _load();
                    },
                    child: const Text('Open'),
                  ),
                  if (!gap.isResolved)
                    OutlinedButton.icon(
                      onPressed: () => _openAction(gap),
                      icon: const Icon(Icons.arrow_forward, size: 17),
                      label: Text(gap.actionLabel),
                    )
                  else if (gap.actionLabel.isNotEmpty)
                    OutlinedButton.icon(
                      onPressed: () => _openAction(gap),
                      icon: const Icon(Icons.open_in_new, size: 17),
                      label: Text(gap.actionLabel),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _smallBadge(String label, Color background, Color foreground) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: foreground,
          ),
        ),
      );

  Future<void> _openAction(CareGapItemData gap) async {
    await _navigateToGapAction(context, gap);
    if (!mounted) return;

    try {
      await CarePlanService.instance.refreshCareGaps(gap.carePlanId);
    } on CarePlanException catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    }

    if (mounted) await _load();
  }

  Widget _guestScreen() {
    final state = CareDemoState.instance;
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final visible = filter == 'All'
            ? state.gaps.where((gap) => gap.status != TaskStatus.resolved).toList()
            : state.gaps
                .where(
                  (gap) =>
                      gap.status != TaskStatus.resolved &&
                      taskStatusLabel(gap.status) == filter,
                )
                .toList();
        return AppShell(
          currentRoute: AppRoutes.careGaps,
          title: 'Care Gaps',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PageHeader(
                title: 'Care Gaps',
                subtitle: 'Demo care gaps',
                action: OutlinedButton(
                  onPressed: () => Navigator.pushReplacementNamed(
                    context,
                    AppRoutes.simulation,
                  ),
                  child: const Text('Back to Simulation'),
                ),
              ),
              if (visible.isEmpty)
                const EmptyState(
                  icon: Icons.shield_outlined,
                  title: 'Everything currently looks ready',
                  description: 'No care gaps match this filter right now.',
                )
              else
                ...visible.map(
                  (gap) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          StatusBadge(status: gap.status),
                          const SizedBox(height: 9),
                          Text(
                            gap.title,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            '${gap.category} · ${gap.when}',
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.muted,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            gap.summary,
                            style: const TextStyle(
                              fontSize: 14,
                              color: AppColors.muted,
                            ),
                          ),
                          const SizedBox(height: 15),
                          FilledButton(
                            onPressed: () => Navigator.pushNamed(
                              context,
                              AppRoutes.careGap(gap.id),
                            ),
                            child: const Text('Open'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class CareGapDetailScreen extends StatefulWidget {
  const CareGapDetailScreen({required this.gapId, super.key});
  final String gapId;

  @override
  State<CareGapDetailScreen> createState() => _CareGapDetailScreenState();
}

class _CareGapDetailScreenState extends State<CareGapDetailScreen> {
  final info = TextEditingController();
  bool loading = true;
  bool saving = false;
  String? error;
  CareGapDetailData? data;

  @override
  void initState() {
    super.initState();
    if (AuthSession.instance.isGuest) {
      loading = false;
    } else {
      _load();
    }
  }

  @override
  void dispose() {
    info.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (AuthSession.instance.isGuest) return;
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final result = await CarePlanService.instance.fetchCareGap(widget.gapId);
      if (!mounted) return;
      setState(() {
        data = result;
        loading = false;
      });
    } on CarePlanException catch (exception) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = exception.message;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'Care gap could not be loaded.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (AuthSession.instance.isGuest) return _guestDetail();

    if (loading) {
      return const AppShell(
        currentRoute: AppRoutes.careGaps,
        title: 'Care Gap',
        child: Center(child: CircularProgressIndicator()),
      );
    }

    final detail = data;
    if (detail == null) {
      return AppShell(
        currentRoute: AppRoutes.careGaps,
        title: 'Care Gap',
        child: EmptyState(
          title: 'Care gap unavailable',
          description: error ?? 'This care gap could not be loaded.',
          action: FilledButton(
            onPressed: _load,
            child: const Text('Try again'),
          ),
        ),
      );
    }

    final gap = detail.gap;
    final main = Column(
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatusBadge(status: gap.badgeStatus),
                  _detailBadge(
                    gap.severityLabel,
                    gap.severityWasBlocking
                        ? AppColors.criticalSoft
                        : AppColors.warningSoft,
                    gap.severityWasBlocking
                        ? AppColors.criticalForeground
                        : AppColors.warningForeground,
                  ),
                  if (!gap.isResolved)
                    _detailBadge(
                      gap.lifecycleLabel,
                      AppColors.infoSoft,
                      AppColors.infoForeground,
                    ),
                ],
              ),
              const SizedBox(height: 16),
              _detail('Problem', gap.summary),
              _detailIfPresent('Related care instruction', gap.instructionSnapshot),
              _detailIfPresent('Why it was flagged', gap.reason),
              _detailIfPresent(
                'Patient information causing the conflict',
                gap.patientReality,
              ),
              _detailIfPresent('What needs to happen', gap.nextStep),
              _detailIfPresent('When / due', _dueText(gap)),
              _detail('Gap type', gap.typeLabel, bottom: gap.resolutionNote.isEmpty),
              if (gap.resolutionNote.isNotEmpty)
                _detail('Resolution note', gap.resolutionNote, bottom: false),
            ],
          ),
        ),
        if (!gap.isResolved && gap.resolutionSteps.isNotEmpty) ...[
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  gap.resolutionTitle,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                ...List.generate(
                  gap.resolutionSteps.length,
                  (index) => Padding(
                    padding: EdgeInsets.only(
                      bottom: index == gap.resolutionSteps.length - 1 ? 0 : 10,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 24,
                          height: 24,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.primaryLight,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(
                            '${index + 1}',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: AppColors.accentForeground,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            gap.resolutionSteps[index],
                            style: const TextStyle(fontSize: 14, height: 1.35),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (gap.autoRecheck) ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.infoSoft,
                      borderRadius: BorderRadius.circular(AppRadii.xl),
                    ),
                    child: const Text(
                      'After you fix the underlying item and return here, SehatRoute will re-check this gap automatically.',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.infoForeground,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
        const SizedBox(height: 16),
        if (!gap.isResolved)
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Add information',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  gap.autoManaged
                      ? 'Add a note while you work on the underlying item. The gap will resolve automatically when that item is fixed.'
                      : 'Add information about how this gap is being handled.',
                  style: const TextStyle(fontSize: 14, color: AppColors.muted),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: info,
                  minLines: 3,
                  maxLines: 4,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    hintText: 'Add an update or resolution note',
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: info.text.trim().isEmpty || saving
                      ? null
                      : () => _saveProgress(gap),
                  child: Text(saving ? 'Saving…' : 'Save progress'),
                ),
              ],
            ),
          ),
        if (detail.doctorQuestions.isNotEmpty) ...[
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Healthcare-professional questions',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                ...detail.doctorQuestions.map(
                  (question) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.secondary,
                        borderRadius: BorderRadius.circular(AppRadii.xl),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            question.title,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 3),
                          Text(question.question),
                          if (question.answered && question.answer.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Verified response: ${question.answer}',
                              style: const TextStyle(
                                color: AppColors.successForeground,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );

    final aside = Column(
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Resolution options',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 12),
              if (!gap.isResolved) ...[
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: saving ? null : () => _openAction(gap),
                    icon: const Icon(Icons.arrow_forward, size: 17),
                    label: Text(gap.actionLabel),
                  ),
                ),
                const SizedBox(height: 10),
                if (gap.canMarkResolved)
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: saving ? null : () => _markResolved(gap),
                      icon: const Icon(Icons.check_circle_outline, size: 17),
                      label: const Text('Mark Resolved'),
                    ),
                  )
                else
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.infoSoft,
                      borderRadius: BorderRadius.circular(AppRadii.xl),
                    ),
                    child: const Text(
                      'This gap is checked automatically. Fix the underlying item, then refresh the status.',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.infoForeground,
                      ),
                    ),
                  ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: saving ? null : () => _createDoctorQuestion(gap),
                    icon: const Icon(Icons.help_outline, size: 17),
                    label: const Text('Create Doctor Question'),
                  ),
                ),
              ] else ...[
                const Text(
                  'This care gap is resolved.',
                  style: TextStyle(color: AppColors.successForeground),
                ),
                if (gap.actionLabel.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: saving ? null : () => _openAction(gap),
                      icon: const Icon(Icons.open_in_new, size: 17),
                      label: Text(gap.actionLabel),
                    ),
                  ),
                ],
              ],
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: saving ? null : _load,
                  icon: const Icon(Icons.refresh, size: 17),
                  label: const Text('Refresh status'),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SafetyNote(
          text:
              'Confirm treatment-related decisions with a qualified healthcare professional. SehatRoute only helps resolve practical care-plan gaps.',
        ),
      ],
    );

    return AppShell(
      currentRoute: AppRoutes.careGap(widget.gapId),
      title: 'Care Gap',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back, size: 18),
            label: const Text('Care Gaps'),
          ),
          PageHeader(
            title: gap.title,
            subtitle: [gap.typeLabel, gap.whenText]
                .where((value) => value.isNotEmpty)
                .join(' · '),
          ),
          LayoutBuilder(
            builder: (context, constraints) => constraints.maxWidth >= 880
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 7, child: main),
                      const SizedBox(width: 24),
                      Expanded(flex: 5, child: aside),
                    ],
                  )
                : Column(
                    children: [
                      main,
                      const SizedBox(height: 16),
                      aside,
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveProgress(CareGapItemData gap) async {
    setState(() => saving = true);
    try {
      await CarePlanService.instance.updateCareGap(
        gap.id,
        lifecycleStatus: 'in_progress',
        resolutionNote: info.text.trim(),
      );
      info.clear();
      await _load();
      if (mounted) showDemoMessage(context, 'Progress saved.');
    } on CarePlanException catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _markResolved(CareGapItemData gap) async {
    setState(() => saving = true);
    try {
      await CarePlanService.instance.updateCareGap(
        gap.id,
        lifecycleStatus: 'resolved',
        resolutionNote: info.text.trim().isEmpty
            ? 'Resolved by the user.'
            : info.text.trim(),
      );
      info.clear();
      await _load();
      if (mounted) showDemoMessage(context, 'Care gap resolved.');
    } on CarePlanException catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _createDoctorQuestion(CareGapItemData gap) async {
    setState(() => saving = true);
    try {
      await CarePlanService.instance.createCareGapDoctorQuestion(
        gap.id,
        groupName: 'Care Instructions',
        title: gap.title,
        question:
            'Regarding "${gap.title}", what should be clarified about the existing care instruction?',
      );
      await _load();
      if (mounted) {
        showDemoMessage(
          context,
          'Question saved for healthcare-professional verification.',
        );
      }
    } on CarePlanException catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _openAction(CareGapItemData gap) async {
    await _navigateToGapAction(context, gap);
    if (!mounted) return;

    try {
      await CarePlanService.instance.refreshCareGaps(gap.carePlanId);
      await _load();
    } on CarePlanException catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    }
  }

  String _dueText(CareGapItemData gap) {
    if (gap.dueAt.isNotEmpty) {
      return gap.dueAt.replaceFirst('T', ' ').replaceFirst(RegExp(r'\.000Z$'), '');
    }
    return gap.whenText;
  }

  Widget _detailIfPresent(String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return _detail(label, value);
  }

  Widget _detail(String label, String value, {bool bottom = true}) => Padding(
        padding: EdgeInsets.only(bottom: bottom ? 16 : 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label.toUpperCase(),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: AppColors.muted,
                letterSpacing: .5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value.trim().isEmpty ? 'Not provided' : value,
              style: const TextStyle(fontSize: 15),
            ),
          ],
        ),
      );

  Widget _detailBadge(String label, Color background, Color foreground) =>
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: foreground,
          ),
        ),
      );

  Widget _guestDetail() {
    final state = CareDemoState.instance;
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final gap = state.gaps.where((item) => item.id == widget.gapId).firstOrNull;
        if (gap == null) {
          return AppShell(
            currentRoute: AppRoutes.careGaps,
            title: 'Care Gap',
            child: EmptyState(
              title: 'Care gap not found',
              description: 'This demo care gap no longer exists.',
              action: FilledButton(
                onPressed: () => Navigator.pushReplacementNamed(
                  context,
                  AppRoutes.careGaps,
                ),
                child: const Text('Back to Care Gaps'),
              ),
            ),
          );
        }
        return AppShell(
          currentRoute: AppRoutes.careGap(widget.gapId),
          title: 'Care Gap',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, size: 18),
                label: const Text('Care Gaps'),
              ),
              PageHeader(title: gap.title, subtitle: '${gap.category} · ${gap.when}'),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StatusBadge(status: gap.status),
                    const SizedBox(height: 16),
                    _detail('Problem', gap.summary),
                    _detail('Related care instruction', gap.instruction),
                    _detail('Why it was flagged', gap.reason),
                    _detail('Patient information causing the conflict', gap.reality),
                    _detail('Suggested next step', gap.nextStep, bottom: false),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class DoctorQuestionsScreen extends StatefulWidget {
  const DoctorQuestionsScreen({super.key});

  @override
  State<DoctorQuestionsScreen> createState() => _DoctorQuestionsScreenState();
}

class _DoctorQuestionsScreenState extends State<DoctorQuestionsScreen> {
  final drafts = <String, TextEditingController>{};

  TextEditingController _controller(String id) => drafts.putIfAbsent(id, TextEditingController.new);

  @override
  void dispose() {
    for (final controller in drafts.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = CareDemoState.instance;
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) => AppShell(
        currentRoute: AppRoutes.doctorQuestions,
        title: 'Doctor Questions',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const PageHeader(title: 'Questions to verify with your healthcare professional', subtitle: 'Take these to your next appointment or phone call.'),
            for (final group in const ['Medicines', 'Follow-Up', 'Tests', 'Care Instructions']) ...[
              if (state.questions.any((question) => question.group == group)) ...[
                Text(group, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                ...state.questions.where((question) => question.group == group).map((question) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: AppCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(question.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)), const SizedBox(height: 4), Text(question.question, style: const TextStyle(fontSize: 15, color: AppColors.muted))])), if (question.answered) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: AppColors.successSoft, borderRadius: BorderRadius.circular(99)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.check, size: 14, color: AppColors.successForeground), SizedBox(width: 4), Text('Answered', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.successForeground))]))]),
                            const SizedBox(height: 14),
                            if (question.answered && question.answer != null)
                              Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.successSoft, borderRadius: BorderRadius.circular(AppRadii.xl)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Verified response', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.successForeground)), Text(question.answer!, style: const TextStyle(fontSize: 15))]))
                            else
                              LayoutBuilder(builder: (context, constraints) {
                                final input = TextField(controller: _controller(question.id), onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Add the answer you received'));
                                final button = FilledButton(onPressed: _controller(question.id).text.trim().isEmpty ? null : () { state.answerQuestion(question.id, _controller(question.id).text.trim()); showDemoMessage(context, 'Answer saved. Simulation will use the verified timing.'); }, child: const Text('Mark Answered'));
                                return constraints.maxWidth >= 600 ? Row(children: [Expanded(child: input), const SizedBox(width: 8), button]) : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [input, const SizedBox(height: 8), button]);
                              }),
                            const SizedBox(height: 10),
                            TextButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: question.question)); showDemoMessage(context, 'Question copied'); }, icon: const Icon(Icons.copy_outlined, size: 17), label: const Text('Copy')),
                          ],
                        ),
                      ),
                    )),
                const SizedBox(height: 18),
              ],
            ],
            const SafetyNote(text: 'SehatRoute does not generate or modify medical treatment. These questions help you clarify the existing care plan with a qualified healthcare professional.'),
          ],
        ),
      ),
    );
  }
}
