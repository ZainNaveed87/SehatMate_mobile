import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_routes.dart';
import '../core/app_theme.dart';
import '../services/auth_service.dart';
import '../services/care_plan_service.dart';
import '../widgets/app_shell.dart';
import '../widgets/care_setup_progress.dart';
import '../widgets/ui.dart';

class RealityCheckScreen extends StatefulWidget {
  const RealityCheckScreen({
    super.key,
    this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String? planId;
  final bool guidedSetup;
  final bool returnToPrevious;

  @override
  State<RealityCheckScreen> createState() => _RealityCheckScreenState();
}

class _RealityCheckScreenState extends State<RealityCheckScreen> {
  int index = 0;
  bool loading = true;
  bool saving = false;
  String? error;
  List<PlanRealityQuestion> questions = const [];
  final answers = <String, String>{};
  final notes = <String, String>{};
  final note = TextEditingController();
  Timer? _autosaveTimer;
  String _saveState = 'Saved';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    if (widget.planId == null || AuthSession.instance.isGuest) {
      setState(() { loading = false; error = 'Open a reviewed care plan to start its reality check.'; });
      return;
    }
    try {
      final result = await CarePlanService.instance.fetchRealityQuestions(widget.planId!);
      if (!mounted) return;
      for (final item in result) {
        if (item.selectedAnswer.isNotEmpty) answers[item.key] = item.selectedAnswer;
        if (item.note.isNotEmpty) notes[item.key] = item.note;
      }
      setState(() { questions = result; loading = false; });
      _syncNote();
    } on CarePlanException catch (exception) {
      if (mounted) setState(() { loading = false; error = exception.message; });
    }
  }

  void _syncNote() { if (questions.isNotEmpty) note.text = notes[questions[index].key] ?? ''; }
  @override
  void dispose() {
    _autosaveTimer?.cancel();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AppShell(
    currentRoute: AppRoutes.realityCheck,
    title: 'Life Reality Check',
    child: Center(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 620),
      child: loading
          ? const Padding(padding: EdgeInsets.all(48), child: Center(child: CircularProgressIndicator()))
          : error != null
              ? EmptyState(icon: Icons.info_outline, title: 'Reality check unavailable', description: error!, action: FilledButton(onPressed: () => Navigator.pushReplacementNamed(context, AppRoutes.carePlans), child: const Text('Open Care Plans')))
              : questions.isEmpty
                  ? EmptyState(
                      icon: Icons.check_circle_outline,
                      title: 'No routine questions needed',
                      description: 'This schedule has no additional practical questions.',
                      action: FilledButton(
                        onPressed: () {
                          if (widget.returnToPrevious && Navigator.canPop(context)) {
                            Navigator.pop(context);
                            return;
                          }
                          Navigator.pushReplacementNamed(
                            context,
                            AppRoutes.simulation,
                            arguments: CareFlowArgs(
                              planId: widget.planId!,
                              guidedSetup: widget.guidedSetup,
                            ),
                          );
                        },
                        child: Text(widget.returnToPrevious ? 'Done' : 'View Simulation'),
                      ),
                    )
                  : _questionView(),
    )),
  );

  Widget _questionView() {
    final question = questions[index];
    final selected = answers[question.key];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (widget.guidedSetup && widget.planId != null) ...[
        GuidedCareSetupProgress(
          currentStep: 4,
          planId: widget.planId!,
          saveState: _saveState,
        ),
        const SizedBox(height: 18),
      ],
      Row(children: [Text('Question ${index + 1} of ${questions.length}', style: const TextStyle(fontSize: 14, color: AppColors.muted)), const Spacer(), Text(question.category, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.primary))]),
      const SizedBox(height: 14),
      ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (index + 1) / questions.length, minHeight: 8, color: AppColors.primary, backgroundColor: AppColors.secondary)),
      const SizedBox(height: 24),
      AppCard(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(question.question, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 20),
        ...question.options.map((option) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: OptionCard(
            label: option,
            selected: selected == option,
            onTap: () => _selectAnswer(question.key, option),
          ),
        )),
        const SizedBox(height: 8),
        TextField(
          controller: note,
          maxLines: 3,
          onChanged: (_) => _scheduleAutosave(),
          decoration: InputDecoration(
            hintText: selected != null &&
                    question.options.isNotEmpty &&
                    selected != question.options.first
                ? 'Optional: tell us when it usually works better (for example, around 9:30 AM)'
                : 'Add useful routine details (optional)',
          ),
        ),
        if (selected != null &&
            question.options.isNotEmpty &&
            selected != question.options.first) ...[
          const SizedBox(height: 10),
          const Text(
            'Keep your honest answer. SehatRoute uses it to suggest practical adjustments; you do not need to choose the first option just to activate the plan.',
            style: TextStyle(
              fontSize: 13,
              color: AppColors.muted,
              height: 1.4,
            ),
          ),
        ],
        const SizedBox(height: 20),
        Row(children: [
          TextButton.icon(
            onPressed: index > 0
                ? _back
                : widget.guidedSetup && widget.planId != null
                    ? _backToSchedule
                    : null,
            icon: const Icon(Icons.arrow_back, size: 17),
            label: Text(index == 0 && widget.guidedSetup ? 'Back to Schedule' : 'Back'),
          ),
          const Spacer(),
          FilledButton(onPressed: selected == null || saving ? null : _next, child: Text(saving ? 'Saving…' : index == questions.length - 1 ? (widget.returnToPrevious ? 'Save changes' : 'Build Simulation') : 'Continue')),
        ]),
      ])),
      const SizedBox(height: 20),
      const SafetyNote(text: 'Only questions relevant to this verified care plan are shown. Answers measure practical feasibility, not medical risk.'),
    ]);
  }

  void _storeNote() {
    if (questions.isNotEmpty) {
      notes[questions[index].key] = note.text.trim();
    }
  }

  void _selectAnswer(String key, String option) {
    setState(() {
      answers[key] = option;
      _saveState = 'Saving…';
    });
    _scheduleAutosave(immediate: true);
  }

  void _scheduleAutosave({bool immediate = false}) {
    if (widget.planId == null || AuthSession.instance.isGuest) return;
    _storeNote();
    _autosaveTimer?.cancel();
    if (mounted) setState(() => _saveState = 'Saving…');
    _autosaveTimer = Timer(
      immediate ? const Duration(milliseconds: 250) : const Duration(milliseconds: 700),
      () => _saveCurrent(showError: false),
    );
  }

  Future<bool> _saveCurrent({required bool showError}) async {
    if (widget.planId == null || AuthSession.instance.isGuest || questions.isEmpty) {
      return true;
    }
    _storeNote();
    final question = questions[index];
    final answer = answers[question.key];
    if (answer == null || answer.isEmpty) return false;

    try {
      if (mounted) setState(() => _saveState = 'Saving…');
      await CarePlanService.instance.saveRealityAnswers(
        widget.planId!,
        [
          {
            'key': question.key,
            'answer': answer,
            'note': notes[question.key] ?? '',
          },
        ],
      );
      if (mounted) setState(() => _saveState = 'Saved');
      return true;
    } on CarePlanException catch (exception) {
      if (mounted) {
        setState(() => _saveState = 'Retry needed');
        if (showError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(exception.message)),
          );
        }
      }
      return false;
    }
  }

  void _back() {
    _storeNote();
    unawaited(_saveCurrent(showError: false));
    setState(() => index--);
    _syncNote();
  }

  void _backToSchedule() {
    _storeNote();
    unawaited(_saveCurrent(showError: false));
    Navigator.pushReplacementNamed(
      context,
      AppRoutes.carePlan(widget.planId!),
      arguments: const CarePlanDetailArgs(
        initialTab: 1,
        guidedSetup: true,
      ),
    );
  }

  Future<void> _next() async {
    _autosaveTimer?.cancel();
    _storeNote();
    final saved = await _saveCurrent(showError: true);
    if (!saved) return;

    if (index < questions.length - 1) {
      setState(() => index++);
      _syncNote();
      return;
    }

    setState(() => saving = true);
    try {
      // Save the full set once at completion as a final consistency check.
      await CarePlanService.instance.saveRealityAnswers(
        widget.planId!,
        questions
            .map(
              (item) => {
                'key': item.key,
                'answer': answers[item.key] ?? '',
                'note': notes[item.key] ?? '',
              },
            )
            .toList(),
      );
      if (widget.guidedSetup && !widget.returnToPrevious) {
        await CarePlanService.instance.updateSetupStep(
          widget.planId!,
          CareSetupStep.simulation,
        );
      }
      if (!mounted) return;
      if (widget.returnToPrevious && Navigator.canPop(context)) {
        Navigator.pop(context);
        return;
      }
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.simulation,
        arguments: CareFlowArgs(
          planId: widget.planId!,
          guidedSetup: widget.guidedSetup,
        ),
      );
    } on CarePlanException catch (exception) {
      if (mounted) {
        setState(() => _saveState = 'Retry needed');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exception.message)),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

}
