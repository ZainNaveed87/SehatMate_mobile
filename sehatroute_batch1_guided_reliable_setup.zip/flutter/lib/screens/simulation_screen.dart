import 'package:flutter/material.dart';

import '../core/app_routes.dart';
import '../core/app_theme.dart';
import '../data/demo_data.dart';
import '../services/care_plan_service.dart';
import '../services/notification_service.dart';
import '../widgets/app_shell.dart';
import '../widgets/care_setup_progress.dart';
import '../widgets/page_header.dart';
import '../widgets/status_badge.dart';
import '../widgets/ui.dart';

class SimulationScreen extends StatelessWidget {
  const SimulationScreen({
    super.key,
    this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String? planId;
  final bool guidedSetup;
  final bool returnToPrevious;

  @override
  Widget build(BuildContext context) => AppShell(
    currentRoute: AppRoutes.simulation,
    title: 'Care Simulation',
    child: SimulationView(
      planId: planId,
      guidedSetup: guidedSetup,
      returnToPrevious: returnToPrevious,
    ),
  );
}

class SimulationView extends StatefulWidget {
  const SimulationView({
    super.key,
    this.compact = false,
    this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final bool compact;
  final String? planId;
  final bool guidedSetup;
  final bool returnToPrevious;

  @override
  State<SimulationView> createState() => _SimulationViewState();
}

class _SimulationViewState extends State<SimulationView> {
  CareSimulationData? data;
  String? error;
  bool loading = true;
  bool activating = false;
  DemoPlan? plan;
  String durationMode = 'prescription';
  DateTime? endDate;
  bool savingDuration = false;
  CareGapListData? careGaps;
  final Set<String> applyingSuggestionIds = <String>{};
  CareSetupProgress? setupProgress;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    if (widget.planId == null) {
      setState(() { loading = false; error = 'Open a care plan to view its real simulation.'; });
      return;
    }
    try {
      final result = await CarePlanService.instance.fetchSimulation(widget.planId!);
      final detail = await CarePlanService.instance.fetchPlanDetail(widget.planId!);
      final gapResult = widget.guidedSetup
          ? await CarePlanService.instance.fetchCareGaps(widget.planId!)
          : null;
      final progress = widget.guidedSetup
          ? await CarePlanService.instance.fetchSetupProgress(widget.planId!)
          : null;
      if (mounted) {
        setState(() {
          data = result;
          careGaps = gapResult;
          setupProgress = progress;
          plan = detail.plan;
          durationMode = detail.plan.durationMode;
          endDate = DateTime.tryParse(detail.plan.plannedEndDate) ??
              DateTime.tryParse(detail.plan.suggestedEndDate) ??
              DateTime.now().add(const Duration(days: 7));
          loading = false;
        });
      }
    } on CarePlanException catch (exception) {
      if (mounted) setState(() { loading = false; error = exception.message; });
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          error = 'The simulation could not be refreshed.';
        });
      }
    }
  }

  Future<void> _refreshSimulation() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Padding(padding: EdgeInsets.all(48), child: Center(child: CircularProgressIndicator()));
    if (error != null || data == null) return EmptyState(icon: Icons.route_outlined, title: 'Simulation unavailable', description: error ?? 'No simulation data found.', action: FilledButton(onPressed: () => Navigator.pushReplacementNamed(context, AppRoutes.carePlans), child: const Text('Open Care Plans')));
    final value = data!;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (widget.guidedSetup && widget.planId != null) ...[
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () {
              if (widget.returnToPrevious && Navigator.canPop(context)) {
                Navigator.pop(context);
                return;
              }
              Navigator.pushReplacementNamed(
                context,
                AppRoutes.realityCheck,
                arguments: CareFlowArgs(
                  planId: widget.planId!,
                  guidedSetup: true,
                ),
              );
            },
            icon: const Icon(Icons.arrow_back, size: 17),
            label: Text(
              widget.returnToPrevious ? 'Back' : 'Back to Reality Check',
            ),
          ),
        ),
      ],
      if (!widget.compact) const PageHeader(title: 'Care Simulation', subtitle: 'A real view built from this plan’s verified schedule and routine answers.'),
      if (widget.guidedSetup && widget.planId != null) ...[
        GuidedCareSetupProgress(
          currentStep: setupProgress?.step == CareSetupStep.activate ? 7 : 5,
          planId: widget.planId!,
          saveState: applyingSuggestionIds.isNotEmpty ? 'Saving…' : 'Saved',
        ),
        const SizedBox(height: 16),
      ],
      AppCard(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        LayoutBuilder(builder: (context, constraints) {
          final score = Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            const Text('Care Feasibility Score', style: TextStyle(fontSize: 13, color: AppColors.muted)),
            Text('${value.readiness} / 100', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700, color: AppColors.primary)),
            StatusBadge(status: value.readiness >= 80 ? TaskStatus.ready : TaskStatus.atRisk, label: value.readiness >= 80 ? 'On Track' : 'Needs Attention'),
          ]);
          const copy = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Plan-specific simulation', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)), SizedBox(height: 4), Text('Calculated from verified tasks and your saved practical answers.', style: TextStyle(fontSize: 14, color: AppColors.muted))]);
          return constraints.maxWidth < 600 ? Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [copy, const SizedBox(height: 16), score]) : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Expanded(child: copy), score]);
        }),
        const SizedBox(height: 20),
        LayoutBuilder(builder: (context, constraints) {
          const gap = 12.0;
          final width = (constraints.maxWidth - gap) / 2;
          final metrics = [
            ('${value.blocked}', 'Blocked', AppColors.criticalSoft, AppColors.criticalForeground),
            ('${value.atRisk}', 'At Risk', AppColors.warningSoft, AppColors.warningForeground),
            ('${value.ready}', 'Ready', AppColors.successSoft, AppColors.successForeground),
            ('${value.unclear}', 'Unclear', AppColors.infoSoft, AppColors.infoForeground),
          ];
          return Wrap(spacing: gap, runSpacing: gap, children: metrics.map((metric) => Container(width: width, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: metric.$3, borderRadius: BorderRadius.circular(AppRadii.xl)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(metric.$1, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: metric.$4)), Text(metric.$2, style: TextStyle(color: metric.$4))]))).toList());
        }),
        const SizedBox(height: 20),
        const SafetyNote(text: 'Care Feasibility measures practical fit only. It is not a medical-risk or clinical-outcome score.'),
      ])),
      if (value.unanswered > 0) ...[
        const SizedBox(height: 16),
        SafetyNote(text: '${value.unanswered} relevant question${value.unanswered == 1 ? '' : 's'} still need an answer, so the score is provisional.'),
      ],
      if (value.findings.isNotEmpty) ...[
        const SizedBox(height: 24),
        const Text(
          'Practical findings',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 6),
        const Text(
          'These are the routine answers used by the simulation. Any reason or recommendation returned by the server is shown here too.',
          style: TextStyle(fontSize: 13, color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        ...value.findings.map((finding) => _findingCard(finding)),
      ],
      const SizedBox(height: 20),
      _activationBlockersCard(value),
      const SizedBox(height: 24),
      const Text('Scheduled tasks', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
      const SizedBox(height: 12),
      ...value.tasks.map((task) => Padding(padding: const EdgeInsets.only(bottom: 10), child: AppCard(padding: const EdgeInsets.all(16), child: Row(children: [
        Icon(task.icon, color: AppColors.primary), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(task.title, style: const TextStyle(fontWeight: FontWeight.w600)), Text('${task.time}${task.note.isEmpty ? '' : ' · ${task.note}'}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted))])),
        const SizedBox(width: 8), StatusBadge(status: task.status),
      ])))),
      if (widget.guidedSetup &&
          !widget.returnToPrevious &&
          widget.planId != null &&
          setupProgress?.step != CareSetupStep.activate) ...[
        const SizedBox(height: 6),
        AppCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                careGaps?.gaps.isEmpty == true
                    ? 'Care Gaps check is ready'
                    : '${careGaps?.gaps.length ?? 0} care gap${(careGaps?.gaps.length ?? 0) == 1 ? '' : 's'} need review',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              Text(
                careGaps?.gaps.isEmpty == true
                    ? 'Continue through Care Gaps once so the guided setup confirms there are no required unresolved issues.'
                    : 'Continue to the plan-specific Care Gaps step. Resolve required blockers, then run the final simulation before activation.',
                style: const TextStyle(fontSize: 14, color: AppColors.muted),
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: _continueToCareGaps,
                icon: const Icon(Icons.arrow_forward, size: 17),
                label: const Text('Continue to Care Gaps'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
      ],
      const SizedBox(height: 16),
      _durationCard(),
      const SizedBox(height: 16),
      AppCard(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(_canActivate(value) ? 'Ready to activate?' : 'Activation requirements', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text(
              _activationMessage(value),
              style: const TextStyle(color: AppColors.muted),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: !_canActivate(value) ||
                      activating ||
                      (widget.guidedSetup && setupProgress?.step != CareSetupStep.activate)
                  ? null
                  : _activate,
              icon: activating
                  ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.notifications_active_outlined, size: 18),
              label: Text(activating ? 'Activating…' : 'Activate Care Plan'),
            ),
          ],
        ),
      ),
    ]);
  }

  Future<void> _continueToCareGaps() async {
    final planId = widget.planId;
    if (planId == null) return;
    try {
      await CarePlanService.instance.updateSetupStep(
        planId,
        CareSetupStep.careGaps,
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.careGaps,
        arguments: CareFlowArgs(planId: planId, guidedSetup: true),
      );
    } on CarePlanException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    }
  }

  Widget _findingCard(Map finding) {
    final category = _findingValue(finding, const ['category']) ?? 'Routine';
    final question = _findingValue(
          finding,
          const ['question', 'title', 'name'],
        ) ??
        'Routine finding';
    final answer = _findingValue(
      finding,
      const ['answer', 'value', 'response'],
    );
    final reason = _findingValue(
      finding,
      const ['reason', 'issue', 'explanation', 'message'],
    );
    final recommendation = _findingValue(
      finding,
      const [
        'recommendation',
        'suggestion',
        'resolution',
        'fix',
        'how_to_fix',
      ],
    );
    final action = _findingValue(finding, const ['action']) ?? '';
    final actionLabel =
        _findingValue(finding, const ['actionLabel', 'action_label']);
    final taskId = _findingValue(finding, const ['taskId', 'task_id']);
    final suggestedTime =
        _findingValue(finding, const ['suggestedTime', 'suggested_time']);
    final suggestedPeriod =
        _findingValue(finding, const ['suggestedPeriod', 'suggested_period']);
    final canApply = finding['canApply'] == true ||
        finding['can_apply'] == true;
    final applying = taskId != null && applyingSuggestionIds.contains(taskId);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    category,
                    style: const TextStyle(
                      fontSize: 13,
                      color: AppColors.muted,
                    ),
                  ),
                ),
                const Text(
                  'Routine adjustment',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.warningForeground,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              question,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            if (answer != null) ...[
              const SizedBox(height: 5),
              Text(
                'Your answer: $answer',
                style: const TextStyle(color: AppColors.muted),
              ),
            ],
            if (reason != null) ...[
              const SizedBox(height: 12),
              const Text(
                'What this means',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 3),
              Text(reason),
            ],
            if (recommendation != null) ...[
              const SizedBox(height: 10),
              const Text(
                'Suggested adjustment',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 3),
              Text(recommendation),
            ],
            if (suggestedTime != null && suggestedPeriod != null) ...[
              const SizedBox(height: 10),
              Text(
                'Suggested reminder: ${_displayScheduleTime(suggestedTime)} · $suggestedPeriod',
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  color: AppColors.primary,
                ),
              ),
            ],
            if (canApply &&
                taskId != null &&
                suggestedTime != null &&
                suggestedPeriod != null) ...[
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: applying
                    ? null
                    : () => _applyScheduleSuggestion(
                          taskId: taskId,
                          scheduleTime: suggestedTime,
                          period: suggestedPeriod,
                        ),
                icon: applying
                    ? const SizedBox.square(
                        dimension: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.auto_fix_high_outlined, size: 17),
                label: Text(
                  applying
                      ? 'Applying…'
                      : actionLabel ?? 'Apply suggestion',
                ),
              ),
            ] else if (action.isNotEmpty) ...[
              const SizedBox(height: 10),
              TextButton.icon(
                onPressed: () => _openFindingAction(action),
                icon: const Icon(Icons.arrow_forward, size: 16),
                label: Text(actionLabel ?? _findingActionLabel(action)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _applyScheduleSuggestion({
    required String taskId,
    required String scheduleTime,
    required String period,
  }) async {
    setState(() => applyingSuggestionIds.add(taskId));
    try {
      await CarePlanService.instance.confirmScheduleItem(
        taskId,
        scheduleTime: scheduleTime,
        displayTime:
            '$period · Confirmed reminder at ${_displayScheduleTime(scheduleTime)}',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Reminder moved to ${_displayScheduleTime(scheduleTime)}. Your Reality Check answer was kept unchanged.',
          ),
        ),
      );
      await _refreshSimulation();
    } on CarePlanException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    } finally {
      if (mounted) {
        setState(() => applyingSuggestionIds.remove(taskId));
      }
    }
  }

  String _displayScheduleTime(String value) {
    final parts = value.split(':');
    if (parts.length < 2) return value;
    final hour24 = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour24 == null || minute == null) return value;
    final suffix = hour24 >= 12 ? 'PM' : 'AM';
    final hour12 = hour24 % 12 == 0 ? 12 : hour24 % 12;
    return '$hour12:${minute.toString().padLeft(2, '0')} $suffix';
  }

  String _findingActionLabel(String action) => switch (action) {
        'schedule' => 'Review schedule',
        'family_care' => 'Open Family Care',
        'calendar' => 'Open Calendar',
        'care_plan' => 'Review care plan',
        _ => 'Review',
      };

  void _openFindingAction(String action) {
    final planId = widget.planId;
    switch (action) {
      case 'schedule':
        if (planId == null) return;
        Navigator.pushNamed(
          context,
          AppRoutes.carePlan(planId),
          arguments: const CarePlanDetailArgs(
            initialTab: 1,
            returnToPrevious: true,
          ),
        );
        return;
      case 'family_care':
        Navigator.pushNamed(context, AppRoutes.family);
        return;
      case 'calendar':
        Navigator.pushNamed(context, AppRoutes.calendar);
        return;
      case 'care_plan':
        if (planId != null) {
          Navigator.pushNamed(context, AppRoutes.carePlan(planId));
        }
        return;
      default:
        _openRealityCheck();
    }
  }

  String? _findingValue(Map finding, List<String> keys) {
    for (final key in keys) {
      final value = finding[key]?.toString().trim();
      if (value != null && value.isNotEmpty && value.toLowerCase() != 'null') {
        return value;
      }
    }
    return null;
  }

  Widget _activationBlockersCard(CareSimulationData value) {
    if (value.activationAllowed) {
      final hasAdjustments = value.atRisk > 0;
      return AppCard(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              hasAdjustments
                  ? Icons.tune_outlined
                  : Icons.check_circle_outline,
              color: hasAdjustments
                  ? AppColors.warningForeground
                  : AppColors.successForeground,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasAdjustments
                        ? 'Plan can activate with routine adjustments'
                        : 'All required activation checks passed',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hasAdjustments
                        ? '${value.atRisk} practical suggestion${value.atRisk == 1 ? '' : 's'} ${value.atRisk == 1 ? 'is' : 'are'} shown above. They are recommendations, not blockers. Keep your honest Reality Check answers and apply only the adjustments that fit your routine.'
                        : 'The required instruction, schedule, and Reality Check information is complete.',
                    style: const TextStyle(color: AppColors.muted),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    final blockers = value.blockers;

    return AppCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.error_outline,
                color: AppColors.criticalForeground,
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Required items before activation',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Only required missing or unverified items block activation. Routine mismatches are shown separately as suggestions.',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _blockerSummary(value),
          ...blockers.map(
            (blocker) => Padding(
              padding: const EdgeInsets.only(top: 12),
              child: _serverBlockerIssueBox(blocker),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              OutlinedButton.icon(
                onPressed: _openCarePlan,
                icon: const Icon(Icons.edit_calendar_outlined, size: 18),
                label: const Text('Review care plan'),
              ),
              OutlinedButton.icon(
                onPressed: _refreshSimulation,
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Refresh check'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _serverBlockerIssueBox(Map blocker) {
    final title =
        _findingValue(blocker, const ['title']) ?? 'Required care-plan item';
    final reason = _findingValue(
          blocker,
          const ['reason', 'summary', 'message'],
        ) ??
        'This required item is not complete yet.';
    final fix = _findingValue(
          blocker,
          const ['recommendation', 'next_step', 'fix'],
        ) ??
        'Review this item and complete the required information.';
    final action = _findingValue(blocker, const ['action']) ?? 'care_plan';

    return _issueBox(
      icon: Icons.block_outlined,
      title: title,
      statusText: 'Required',
      reason: reason,
      fix: fix,
      foreground: AppColors.criticalForeground,
      background: AppColors.criticalSoft,
      actionLabel: _findingActionLabel(action),
      onAction: () => _openFindingAction(action),
    );
  }

  Widget _blockerSummary(CareSimulationData value) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.criticalSoft,
        borderRadius: BorderRadius.circular(AppRadii.xl),
      ),
      child: Text(
        '${value.hardBlockerCount} required item${value.hardBlockerCount == 1 ? '' : 's'} must be completed before activation.',
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          color: AppColors.criticalForeground,
        ),
      ),
    );
  }

  Widget _issueBox({
    required IconData icon,
    required String title,
    required String statusText,
    required String reason,
    required String fix,
    required Color foreground,
    required Color background,
    String? details,
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppRadii.xl),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 20, color: foreground),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: foreground,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                statusText,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: foreground,
                ),
              ),
            ],
          ),
          if (details != null) ...[
            const SizedBox(height: 7),
            Text(
              details,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.muted,
              ),
            ),
          ],
          const SizedBox(height: 10),
          const Text(
            'Why',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(reason),
          const SizedBox(height: 9),
          Text(
            'How to fix',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: foreground,
            ),
          ),
          const SizedBox(height: 2),
          Text(fix),
          if (onAction != null && actionLabel != null) ...[
            const SizedBox(height: 10),
            TextButton.icon(
              onPressed: onAction,
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
                visualDensity: VisualDensity.compact,
                foregroundColor: foreground,
              ),
              icon: const Icon(Icons.arrow_forward, size: 16),
              label: Text(actionLabel),
            ),
          ],
        ],
      ),
    );
  }

  void _openCarePlan() {
    final planId = widget.planId;
    if (planId == null) return;
    Navigator.pushNamed(context, AppRoutes.carePlan(planId));
  }

  void _openRealityCheck() {
    final planId = widget.planId;
    if (planId == null) return;
    Navigator.pushNamed(
      context,
      AppRoutes.realityCheck,
      arguments: CareFlowArgs(planId: planId),
    );
  }

  String _activationMessage(CareSimulationData value) {
    if (widget.guidedSetup && setupProgress?.step != CareSetupStep.activate) {
      return 'Continue to Care Gaps before activation. After that step, SehatRoute will bring you back here for the final simulation.';
    }
    if (_canActivate(value)) {
      if (value.atRisk > 0) {
        return 'The required checks are complete. You can activate now and keep the current routine, or apply any practical suggestions above first.';
      }
      return 'All required activation checks passed. Confirmed exact times will be used for reminders on this device.';
    }

    return 'Activation is waiting for ${value.hardBlockerCount} required item${value.hardBlockerCount == 1 ? '' : 's'}. Routine suggestions do not block activation.';
  }

  bool _canActivate(CareSimulationData value) => value.activationAllowed;

  Widget _durationCard() => AppCard(
    padding: const EdgeInsets.all(20),
    child: RadioGroup<String>(
      groupValue: durationMode,
      onChanged: (value) {
        if (value == null) return;
        setState(() => durationMode = value);
        if (value == 'custom') {
          _pickEndDate();
        }
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Plan duration',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          const Text(
            'Medicine-specific durations remain unchanged.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 12),
          RadioListTile<String>(
            contentPadding: EdgeInsets.zero,
            value: 'prescription',
            title: const Text('Use prescription duration'),
            subtitle: Text(
              plan?.suggestedEndDate.isNotEmpty == true
                  ? 'Suggested end: ${plan!.suggestedEndDate}'
                  : 'Uses the latest verified instruction end date',
            ),
          ),
          RadioListTile<String>(
            contentPadding: EdgeInsets.zero,
            value: 'custom',
            title: const Text('Choose end date'),
            subtitle: Text(
              endDate == null
                  ? 'No date selected'
                  : '${endDate!.year}-${endDate!.month.toString().padLeft(2, '0')}-${endDate!.day.toString().padLeft(2, '0')}',
            ),
          ),
          const RadioListTile<String>(
            contentPadding: EdgeInsets.zero,
            value: 'ongoing',
            title: Text('Ongoing plan'),
            subtitle: Text(
              'The plan stays active; fixed medicine durations still stop as prescribed.',
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: savingDuration ? null : _saveDuration,
            icon: savingDuration
                ? const SizedBox.square(
                    dimension: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.event_available_outlined),
            label: const Text('Save duration'),
          ),
        ],
      ),
    ),
  );

  Future<void> _pickEndDate() async {
    final selected = await showDatePicker(context: context, initialDate: endDate ?? DateTime.now().add(const Duration(days: 7)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 3650)));
    if (selected != null && mounted) setState(() => endDate = selected);
  }

  String? get _endDateText => durationMode == 'ongoing' ? null : endDate == null ? null : '${endDate!.year}-${endDate!.month.toString().padLeft(2, '0')}-${endDate!.day.toString().padLeft(2, '0')}';

  Future<void> _saveDuration() async {
    if (durationMode != 'ongoing' && endDate == null) { await _pickEndDate(); if (endDate == null) return; }
    setState(() => savingDuration = true);
    try {
      await CarePlanService.instance.savePlanDuration(widget.planId!, mode: durationMode, endDate: _endDateText);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plan duration saved.')));
    } on CarePlanException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally { if (mounted) setState(() => savingDuration = false); }
  }

  Future<void> _activate() async {
    final planId = widget.planId;
    if (planId == null) return;
    setState(() => activating = true);
    try {
      await CarePlanService.instance.savePlanDuration(planId, mode: durationMode, endDate: _endDateText);
      final detail = await CarePlanService.instance.activatePlan(planId);
      final notificationResult = await NotificationService.instance.scheduleNextOccurrences(
        planId: planId,
        tasks: detail.tasks,
      );
      if (!mounted) return;
      final message = !notificationResult.permissionGranted
          ? 'Care plan activated, but notification permission was not granted.'
          : !notificationResult.exactAlarmGranted
              ? 'Care plan activated. Allow exact alarms in Android settings to enable reminders.'
              : 'Care plan activated. ${notificationResult.scheduledCount} reminder${notificationResult.scheduledCount == 1 ? '' : 's'} scheduled.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.dashboard, (route) => false);
    } on CarePlanException catch (exception) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(exception.message)));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('The care plan could not be activated on this device.')),
        );
      }
    } finally {
      if (mounted) setState(() => activating = false);
    }
  }
}
