import 'package:flutter/material.dart';

import '../core/app_routes.dart';
import '../core/app_theme.dart';
import '../core/care_setup_flow.dart';
import '../data/demo_data.dart';
import '../services/auth_service.dart';
import '../services/care_plan_service.dart';
import '../services/notification_service.dart';
import '../widgets/app_shell.dart';
import '../widgets/page_header.dart';
import '../widgets/status_badge.dart';
import '../widgets/ui.dart';

class CarePlansScreen extends StatefulWidget {
  const CarePlansScreen({super.key});

  @override
  State<CarePlansScreen> createState() => _CarePlansScreenState();
}

class _CarePlansScreenState extends State<CarePlansScreen> {
  int selected = 0;
  List<DemoPlan> _plans = const [];
  bool _loading = true;
  String? _error;
  final Set<String> _selectedIds = {};
  final Map<String, CareSetupProgress> _setupProgress = {};

  @override
  void initState() {
    super.initState();
    _loadPlans();
  }

  Future<void> _loadPlans() async {
    if (AuthSession.instance.isGuest) {
      setState(() {
        _plans = demoPlans;
        _loading = false;
        _error = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final plans = await CarePlanService.instance.fetchPlans();
      for (final plan in plans.where((item) => item.status == PlanStatus.completed)) {
        await NotificationService.instance.cancelPlan(plan.id);
      }
      final pending = plans.where(
        (plan) =>
            plan.status != PlanStatus.active &&
            plan.status != PlanStatus.completed,
      );
      final progressEntries = await Future.wait(
        pending.map((plan) async {
          try {
            return MapEntry(
              plan.id,
              await CarePlanService.instance.resolveSetupProgress(plan),
            );
          } on CarePlanException {
            return null;
          }
        }),
      );
      if (!mounted) return;
      setState(() {
        _plans = plans;
        _setupProgress
          ..clear()
          ..addEntries(progressEntries.whereType<MapEntry<String, CareSetupProgress>>());
        _loading = false;
      });
    } on CarePlanException catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.message;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Care plans could not be loaded.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final lists = [
      _plans.where((plan) => plan.status == PlanStatus.active).toList(),
      _plans.where((plan) => plan.status == PlanStatus.draft || plan.status == PlanStatus.processing || plan.status == PlanStatus.needsReview || plan.status == PlanStatus.realityCheck || plan.status == PlanStatus.needsAttention).toList(),
      _plans.where((plan) => plan.status == PlanStatus.completed).toList(),
    ];
    return AppShell(
      currentRoute: AppRoutes.carePlans,
      title: 'Care Plans',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          PageHeader(
            title: 'Care Plans',
            subtitle: 'Every plan built from verified doctor instructions.',
            action: FilledButton.icon(
              onPressed: () => Navigator.pushNamed(context, AppRoutes.carePlanNew),
              icon: const Icon(Icons.add, size: 17),
              label: const Text('New Care Plan'),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: AppTabs<int>(
              tabs: const [AppTab(0, 'Active'), AppTab(1, 'Draft'), AppTab(2, 'Completed')],
              selected: selected,
              onChanged: (value) => setState(() { selected = value; _selectedIds.clear(); }),
            ),
          ),
          const SizedBox(height: 20),
          if (!_loading && _error == null && lists[selected].isNotEmpty && !AuthSession.instance.isGuest) ...[
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => setState(() {
                    final ids = lists[selected].map((item) => item.id).toSet();
                    if (_selectedIds.containsAll(ids)) { _selectedIds.clear(); } else { _selectedIds..clear()..addAll(ids); }
                  }),
                  icon: Icon(_selectedIds.containsAll(lists[selected].map((item) => item.id)) ? Icons.deselect : Icons.select_all),
                  label: Text(_selectedIds.containsAll(lists[selected].map((item) => item.id)) ? 'Clear selection' : 'Select all'),
                ),
                if (_selectedIds.isNotEmpty)
                  FilledButton.icon(
                    onPressed: () => _deleteSelected(_selectedIds.toList()),
                    style: FilledButton.styleFrom(backgroundColor: AppColors.criticalForeground),
                    icon: const Icon(Icons.delete_outline),
                    label: Text('Delete selected (${_selectedIds.length})'),
                  ),
                OutlinedButton.icon(
                  onPressed: () => _deleteSelected(lists[selected].map((item) => item.id).toList(), all: true),
                  icon: const Icon(Icons.delete_sweep_outlined),
                  label: Text('Delete all ${['active', 'draft', 'completed'][selected]}'),
                ),
              ],
            ),
            const SizedBox(height: 14),
          ],
          if (_loading)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 48),
                child: CircularProgressIndicator(),
              ),
            )
          else if (_error != null)
            AppCard(
              child: Column(
                children: [
                  Text(_error!, textAlign: TextAlign.center),
                  const SizedBox(height: 14),
                  OutlinedButton(onPressed: _loadPlans, child: const Text('Try again')),
                ],
              ),
            )
          else
            _PlanGrid(
              plans: lists[selected],
              onDelete: !AuthSession.instance.isGuest ? _deletePlan : null,
              onComplete: !AuthSession.instance.isGuest ? _completePlan : null,
              setupProgress: _setupProgress,
              selectedIds: _selectedIds,
              onSelectionChanged: (plan, checked) => setState(() {
                if (checked) { _selectedIds.add(plan.id); } else { _selectedIds.remove(plan.id); }
              }),
            ),
        ],
      ),
    );
  }

  Future<void> _deletePlan(DemoPlan plan) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete care plan?'),
        content: Text(
          '${plan.title} and its uploaded documents, extracted instructions, schedule, and answers will be permanently deleted.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.criticalForeground),
            child: const Text('Delete plan'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    try {
      await NotificationService.instance.cancelPlan(plan.id);
      await CarePlanService.instance.deletePlan(plan.id);
      if (!mounted) return;
      setState(() => _plans = _plans.where((item) => item.id != plan.id).toList());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Care plan and its reminders deleted.')),
      );
    } on CarePlanException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
      }
    }
  }

  Future<void> _deleteSelected(List<String> ids, {bool all = false}) async {
    final confirmed = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: Text(all ? 'Delete all plans in this section?' : 'Delete selected plans?'),
      content: Text('${ids.length} care plan${ids.length == 1 ? '' : 's'} and their reminders will be permanently deleted.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
        FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.criticalForeground), onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete')),
      ],
    ));
    if (confirmed != true || !mounted) return;
    try {
      for (final id in ids) { await NotificationService.instance.cancelPlan(id); }
      await CarePlanService.instance.deletePlans(ids);
      if (!mounted) return;
      setState(() { _plans = _plans.where((item) => !ids.contains(item.id)).toList(); _selectedIds.clear(); });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selected care plans deleted.')));
    } on CarePlanException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    }
  }

  Future<void> _completePlan(DemoPlan plan) async {
    final confirmed = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Complete this plan now?'),
      content: const Text('Future reminders for this plan will be removed. You can still view it under Completed.'),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Complete plan'))],
    ));
    if (confirmed != true) return;
    try {
      await NotificationService.instance.cancelPlan(plan.id);
      await CarePlanService.instance.completePlan(plan.id);
      await _loadPlans();
    } on CarePlanException catch (error) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message))); }
  }
}

class _PlanGrid extends StatelessWidget {
  const _PlanGrid({required this.plans, this.onDelete, this.onComplete, required this.setupProgress, required this.selectedIds, required this.onSelectionChanged});
  final List<DemoPlan> plans;
  final Future<void> Function(DemoPlan plan)? onDelete;
  final Future<void> Function(DemoPlan plan)? onComplete;
  final Map<String, CareSetupProgress> setupProgress;
  final Set<String> selectedIds;
  final void Function(DemoPlan plan, bool selected) onSelectionChanged;

  @override
  Widget build(BuildContext context) {
    if (plans.isEmpty) {
      return AppCard(
        child: Column(
          children: [
            const CircleAvatar(radius: 22, backgroundColor: AppColors.primaryLight, child: Icon(Icons.checklist_outlined, color: AppColors.primary)),
            const SizedBox(height: 12),
            const Text('No care plans here yet', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            const Text("You don't have a care plan in this state yet.", style: TextStyle(fontSize: 14, color: AppColors.muted)),
            const SizedBox(height: 18),
            FilledButton(onPressed: () => Navigator.pushNamed(context, AppRoutes.carePlanNew), child: const Text('Create Care Plan')),
          ],
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 720 ? 2 : 1;
        const gap = 16.0;
        final width = (constraints.maxWidth - (columns - 1) * gap) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: plans.map((plan) => SizedBox(
            width: width,
            child: _PlanCard(plan: plan, onDelete: onDelete, onComplete: onComplete, setupProgress: setupProgress[plan.id], selected: selectedIds.contains(plan.id), onSelectionChanged: onSelectionChanged),
          )).toList(),
        );
      },
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({required this.plan, this.onDelete, this.onComplete, this.setupProgress, required this.selected, required this.onSelectionChanged});
  final DemoPlan plan;
  final Future<void> Function(DemoPlan plan)? onDelete;
  final Future<void> Function(DemoPlan plan)? onComplete;
  final CareSetupProgress? setupProgress;
  final bool selected;
  final void Function(DemoPlan plan, bool selected) onSelectionChanged;

  @override
  Widget build(BuildContext context) => HoverLift(
        cursor: SystemMouseCursors.click,
        child: InkWell(
          onTap: () => _openPlan(context, plan),
          borderRadius: BorderRadius.circular(AppRadii.xxl),
          child: AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Checkbox(value: selected, onChanged: (value) => onSelectionChanged(plan, value ?? false)),
                  Expanded(child: Text(plan.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
                  if (onDelete != null || (plan.status == PlanStatus.active && onComplete != null))
                    PopupMenuButton<String>(
                      tooltip: 'Plan actions',
                      onSelected: (value) {
                        if (value == 'complete') onComplete?.call(plan);
                        if (value == 'delete') onDelete?.call(plan);
                      },
                      itemBuilder: (_) => [
                        if (plan.status == PlanStatus.active && onComplete != null)
                          const PopupMenuItem(value: 'complete', child: Text('Complete plan')),
                        if (onDelete != null)
                          const PopupMenuItem(value: 'delete', child: Text('Delete plan')),
                      ],
                    ),
                ],
              ),
              const SizedBox(height: 4),
              PlanStatusBadge(status: plan.status),
              const SizedBox(height: 8),
              Text('Started ${plan.startDate}', style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Expanded(child: Text('Care readiness', style: TextStyle(fontSize: 13, color: AppColors.muted))),
                  Text('${plan.readiness}%', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(value: plan.readiness / 100, minHeight: 8, color: AppColors.primary, backgroundColor: AppColors.secondary),
              ),
              const SizedBox(height: 16),
              if (setupProgress != null &&
                  plan.status != PlanStatus.active &&
                  plan.status != PlanStatus.completed) ...[
                Text(
                  'Setup ${setupProgress!.completedCount} of ${CareSetupProgress.totalSteps} complete',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(height: 4),
                Text.rich(
                  TextSpan(
                    children: [
                      const TextSpan(
                        text: 'Next: ',
                        style: TextStyle(color: AppColors.muted),
                      ),
                      TextSpan(text: setupProgress!.title),
                    ],
                  ),
                  style: const TextStyle(fontSize: 14),
                ),
              ] else
                Text.rich(
                  TextSpan(children: [const TextSpan(text: 'Next: ', style: TextStyle(color: AppColors.muted)), TextSpan(text: plan.nextTask)]),
                  style: const TextStyle(fontSize: 14),
                ),
              if (plan.status != PlanStatus.active && plan.status != PlanStatus.completed) ...[
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => _openPlan(context, plan),
                    icon: const Icon(Icons.arrow_forward, size: 17),
                    label: const Text('Continue setup'),
                  ),
                ),
              ],
            ],
          ),
          ),
        ),
      );
}

Future<void> _openPlan(BuildContext context, DemoPlan plan) async {
  if (plan.status == PlanStatus.active || plan.status == PlanStatus.completed) {
    await Navigator.pushNamed(context, AppRoutes.carePlan(plan.id));
    return;
  }

  try {
    await CareSetupFlow.resume(context, plan);
  } on CarePlanException catch (error) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.message)),
      );
    }
  }
}

class NewCarePlanScreen extends StatefulWidget {
  const NewCarePlanScreen({super.key});

  @override
  State<NewCarePlanScreen> createState() => _NewCarePlanScreenState();
}

class _NewCarePlanScreenState extends State<NewCarePlanScreen> {
  final selected = <String>{'prescription'};
  bool _creating = false;
  static const options = [
    ('prescription', 'Prescription', Icons.medication_outlined, 'Medicines, doses and timings.'),
    ('discharge', 'Discharge Summary', Icons.local_hospital_outlined, 'Instructions after leaving hospital.'),
    ('followup', 'Follow-Up Instructions', Icons.description_outlined, 'Next appointments and reviews.'),
    ('lab', 'Lab Instructions', Icons.biotech_outlined, 'Tests and sample requirements.'),
    ('other', 'Other Medical Instructions', Icons.note_alt_outlined, 'Anything else from your clinic.'),
  ];

  @override
  Widget build(BuildContext context) => AppShell(
        currentRoute: AppRoutes.carePlanNew,
        title: 'New Care Plan',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () => Navigator.pushReplacementNamed(context, AppRoutes.carePlans),
                icon: const Icon(Icons.arrow_back, size: 17),
                label: const Text('Care Plans'),
              ),
            ),
            const PageHeader(title: 'What would you like to add?', subtitle: 'Select every document type you have. You can add more later.'),
            LayoutBuilder(
              builder: (context, constraints) {
                final columns = constraints.maxWidth >= 650 ? 2 : 1;
                const gap = 12.0;
                final width = (constraints.maxWidth - (columns - 1) * gap) / columns;
                return Wrap(
                  spacing: gap,
                  runSpacing: gap,
                  children: options.map((option) => SizedBox(width: width, child: _option(option))).toList(),
                );
              },
            ),
            const SizedBox(height: 24),
            const SafetyNote(text: 'SehatRoute organizes instructions that a healthcare professional has already given. It does not diagnose conditions or change treatment.'),
            const SizedBox(height: 24),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: selected.isEmpty || _creating ? null : _continue,
                iconAlignment: IconAlignment.end,
                icon: const Icon(Icons.arrow_forward, size: 17),
                label: const Text('Continue'),
              ),
            ),
          ],
        ),
      );

  Future<void> _continue() async {
    if (AuthSession.instance.isGuest) {
      Navigator.pushNamed(context, AppRoutes.carePlanUpload);
      return;
    }

    setState(() => _creating = true);
    try {
      final selectedLabels = options
          .where((option) => selected.contains(option.$1))
          .map((option) => option.$2)
          .toList();
      final title = selectedLabels.length == 1
          ? '${selectedLabels.first} Care Plan'
          : 'Combined Care Plan';
      final plan = await CarePlanService.instance.createPlan(title);
      if (!mounted) return;
      Navigator.pushNamed(
        context,
        AppRoutes.carePlanUpload,
        arguments: CarePlanUploadArgs(
          planId: plan.id,
          documentTypes: selected.toList(),
          guidedSetup: true,
        ),
      );
    } on CarePlanException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.message)),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Care plan could not be created.')),
      );
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  Widget _option((String, String, IconData, String) option) {
    final active = selected.contains(option.$1);
    return InkWell(
      onTap: () => setState(() => active ? selected.remove(option.$1) : selected.add(option.$1)),
      borderRadius: BorderRadius.circular(AppRadii.xxl),
      child: AppCard(
        padding: const EdgeInsets.all(20),
        color: active ? AppColors.primaryLight : AppColors.card,
        borderColor: active ? AppColors.primary : AppColors.border,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(AppRadii.xl)),
              child: Icon(option.$3, size: 20, color: AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(option.$2, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(option.$4, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                ],
              ),
            ),
            if (active) const Icon(Icons.check, size: 20, color: AppColors.primary),
          ],
        ),
      ),
    );
  }
}
