import 'package:flutter/material.dart';

import '../core/app_routes.dart';
import '../core/app_theme.dart';
import '../core/care_setup_flow.dart';
import '../data/demo_data.dart';
import '../widgets/app_shell.dart';
import '../widgets/page_header.dart';
import '../widgets/status_badge.dart';
import '../widgets/ui.dart';
import '../services/auth_service.dart';
import '../services/care_plan_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final state = CareDemoState.instance;
  DemoPlan? _setupPlan;
  CareSetupProgress? _setupProgress;

  @override
  void initState() {
    super.initState();
    state.addListener(_refresh);
    _loadSetupPlan();
  }

  @override
  void dispose() {
    state.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() => setState(() {});
  void _go(String route) => Navigator.pushNamed(context, route);

  Future<void> _loadSetupPlan() async {
    if (AuthSession.instance.isGuest) return;
    try {
      final plans = await CarePlanService.instance.fetchPlans();
      if (!mounted) return;
      final setupPlan = plans
          .where(
            (plan) =>
                plan.status != PlanStatus.active &&
                plan.status != PlanStatus.completed,
          )
          .firstOrNull;
      final progress = setupPlan == null
          ? null
          : await CarePlanService.instance.resolveSetupProgress(setupPlan);
      if (!mounted) return;
      setState(() {
        _setupPlan = setupPlan;
        _setupProgress = progress;
      });
    } on CarePlanException {
      // The normal dashboard remains available if setup progress cannot load.
    }
  }

  Future<void> _continueSetup(DemoPlan plan) async {
    try {
      await CareSetupFlow.resume(context, plan);
      if (mounted) await _loadSetupPlan();
    } on CarePlanException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final todayTasks = state.tasks.where((task) => task.day == demoDays.first.iso).toList();
    final completed = todayTasks.where((task) => task.completed).length;
    final openGaps = state.gaps.where((gap) => gap.status != TaskStatus.resolved).length;
    final compactHeader = MediaQuery.sizeOf(context).width < 560;
    final firstName = AuthSession.instance.user?.name
            .trim()
            .split(RegExp(r'\s+'))
            .where((part) => part.isNotEmpty)
            .firstOrNull ??
        'Guest';
    final hour = DateTime.now().hour;
    final greeting = hour < 12
        ? 'Good morning'
        : hour < 17
            ? 'Good afternoon'
            : 'Good evening';

    return AppShell(
      currentRoute: AppRoutes.dashboard,
      title: '$greeting, $firstName',
      subtitle: "Here's your care overview for today.",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          PageHeader(
            title: '$greeting, $firstName',
            subtitle: "Here's your care overview for today.",
            action: compactHeader
                ? IconButton.filled(
                    onPressed: () => _go(AppRoutes.carePlanNew),
                    icon: const Icon(Icons.upload_outlined),
                    tooltip: 'Upload New Care Plan',
                  )
                : FilledButton.icon(
                    onPressed: () => _go(AppRoutes.carePlanNew),
                    icon: const Icon(Icons.upload_outlined, size: 17),
                    label: const Text('Upload New Care Plan'),
                  ),
          ),
          if (_setupPlan != null) ...[
            AppCard(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const CircleAvatar(
                    radius: 21,
                    backgroundColor: AppColors.primaryLight,
                    child: Icon(Icons.route_outlined, color: AppColors.primary, size: 19),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Care plan setup incomplete', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 3),
                        Text(_setupPlan!.title, style: const TextStyle(fontSize: 14)),
                        const SizedBox(height: 3),
                        if (_setupProgress != null) ...[
                          Text(
                            'Setup ${_setupProgress!.completedCount} of ${CareSetupProgress.totalSteps} complete',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Next: ${_setupProgress!.title}',
                            style: const TextStyle(fontSize: 13, color: AppColors.muted),
                          ),
                        ] else
                          Text('Next: ${_setupPlan!.nextTask}', style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton(
                    onPressed: () => _continueSetup(_setupPlan!),
                    child: const Text('Continue setup'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
          ],
          _MetricGrid(
            children: [
              _MetricCard(label: 'Care Readiness', value: '${state.readiness}%', hint: 'Good', onTap: () => _go(AppRoutes.simulation)),
              _MetricCard(label: "Today's Tasks", value: '${todayTasks.length}', hint: '$completed completed', onTap: () => _go(AppRoutes.carePlan('p1'))),
              _MetricCard(label: 'Care Gaps', value: '$openGaps', hint: 'Need attention', onTap: () => _go(AppRoutes.careGaps)),
              _MetricCard(label: 'Understanding', value: '${state.understanding}%', hint: 'Last Teach-Back', onTap: () => _go(AppRoutes.teachBack)),
            ],
          ),
          const SizedBox(height: 32),
          LayoutBuilder(
            builder: (context, constraints) {
              final narrow = constraints.maxWidth < 900;
              final care = _TodayAndJourney(
                tasks: todayTasks,
                allTasks: state.tasks,
                onToggle: state.toggleTask,
                onNavigate: _go,
              );
              final aside = _DashboardAside(onNavigate: _go, understanding: state.understanding);
              if (narrow) return Column(children: [care, const SizedBox(height: 28), aside]);
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(flex: 14, child: care),
                  const SizedBox(width: 24),
                  Expanded(flex: 10, child: aside),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MetricGrid extends StatelessWidget {
  const _MetricGrid({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth < 560 ? 1 : constraints.maxWidth < 980 ? 2 : 4;
          const gap = 16.0;
          final width = (constraints.maxWidth - (columns - 1) * gap) / columns;
          return Wrap(spacing: gap, runSpacing: gap, children: children.map((child) => SizedBox(width: width, child: child)).toList());
        },
      );
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value, required this.hint, required this.onTap});
  final String label;
  final String value;
  final String hint;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => HoverLift(
        cursor: SystemMouseCursors.click,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppRadii.xxl),
          child: AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 14, color: AppColors.muted)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(fontSize: 32, height: 1.2, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(hint, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              ],
            ),
          ),
        ),
      );
}

class _TodayAndJourney extends StatelessWidget {
  const _TodayAndJourney({required this.tasks, required this.allTasks, required this.onToggle, required this.onNavigate});
  final List<DemoTask> tasks;
  final List<DemoTask> allTasks;
  final ValueChanged<String> onToggle;
  final ValueChanged<String> onNavigate;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SectionTitle(
            title: "Today's Care",
            action: TextButton.icon(
              onPressed: () => onNavigate(AppRoutes.calendar),
              iconAlignment: IconAlignment.end,
              icon: const Icon(Icons.arrow_forward, size: 16),
              label: const Text('Calendar'),
            ),
          ),
          ...tasks.map(
            (task) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _TaskRow(task: task, onToggle: () => onToggle(task.id)),
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Care Journey'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Next 7 days', style: TextStyle(fontSize: 14, color: AppColors.muted)),
                const SizedBox(height: 16),
                Row(
                  children: List.generate(demoDays.length, (index) {
                    final day = demoDays[index];
                    final tasks = allTasks.where((task) => task.day == day.iso).toList();
                    final color = tasks.any((task) => task.status == TaskStatus.blocked)
                        ? AppColors.critical
                        : tasks.any((task) => task.status == TaskStatus.atRisk)
                            ? AppColors.warning
                            : tasks.isNotEmpty
                                ? AppColors.success
                                : AppColors.border;
                    return Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(right: index == demoDays.length - 1 ? 0 : 8),
                        child: Column(
                          children: [
                            Text(day.short, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                            const SizedBox(height: 8),
                            Container(height: 56, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(AppRadii.lg))),
                            const SizedBox(height: 5),
                            Text(index == 0 ? 'Today' : '${day.number}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                          ],
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                const Wrap(
                  spacing: 16,
                  runSpacing: 8,
                  children: [
                    _Legend(color: AppColors.success, text: 'Ready'),
                    _Legend(color: AppColors.warning, text: 'At risk'),
                    _Legend(color: AppColors.critical, text: 'Blocked'),
                  ],
                ),
              ],
            ),
          ),
        ],
      );
}

class _TaskRow extends StatelessWidget {
  const _TaskRow({required this.task, required this.onToggle});
  final DemoTask task;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) => AppCard(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(AppRadii.xl)),
              child: Icon(task.icon, size: 18, color: AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${task.time} · ${task.title}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  Text(task.note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            if (task.completed)
              const StatusBadge(status: TaskStatus.ready, label: 'Completed')
            else
              OutlinedButton(onPressed: onToggle, child: const Text('Mark done')),
          ],
        ),
      );
}

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.text});
  final Color color;
  final String text;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(radius: 5, backgroundColor: color),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
        ],
      );
}

class _DashboardAside extends StatelessWidget {
  const _DashboardAside({required this.onNavigate, required this.understanding});
  final ValueChanged<String> onNavigate;
  final int understanding;

  @override
  Widget build(BuildContext context) {
    final alert = CareDemoState.instance.gaps.where((gap) => gap.status != TaskStatus.resolved).firstOrNull;
    const quickActions = [
      (AppRoutes.carePlanNew, 'Upload New Care Plan', Icons.upload_outlined),
      (AppRoutes.teachBack, 'Start Teach-Back', Icons.record_voice_over_outlined),
      (AppRoutes.familyNew, 'Add Caregiver', Icons.person_add_alt_1_outlined),
      (AppRoutes.simulation, 'View Simulation', Icons.route_outlined),
      (AppRoutes.calendar, 'Open Calendar', Icons.calendar_month_outlined),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SectionTitle(title: 'Needs Attention'),
        AppCard(
          child: alert == null
              ? const Text('Everything currently looks ready.', style: TextStyle(fontSize: 14, color: AppColors.muted))
              : Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StatusBadge(status: alert.status),
              const SizedBox(height: 12),
              Text(alert.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
              const SizedBox(height: 3),
              Text(alert.when, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              const SizedBox(height: 8),
              Text(alert.summary, style: const TextStyle(fontSize: 14, color: AppColors.muted)),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: () => onNavigate(AppRoutes.careGap(alert.id)), child: const Text('Resolve')),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle(title: 'Understanding'),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$understanding%', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: AppColors.primary)),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(value: understanding / 100, minHeight: 8, color: AppColors.primary, backgroundColor: AppColors.secondary),
              ),
              const SizedBox(height: 12),
              const Text('Based on the last Teach-Back session.', style: TextStyle(fontSize: 13, color: AppColors.muted)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle(title: 'Quick Actions'),
        ...quickActions.map(
          (action) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              onTap: () => onNavigate(action.$1),
              borderRadius: BorderRadius.circular(AppRadii.xl),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                radius: AppRadii.xl,
                child: Row(
                  children: [
                    Icon(action.$3, size: 18, color: AppColors.primary),
                    const SizedBox(width: 12),
                    Text(action.$2, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        const SafetyNote(text: 'SehatRoute helps organize and understand an existing care plan. It does not diagnose conditions or prescribe treatment.'),
      ],
    );
  }
}
