import 'package:flutter/material.dart';

import '../screens/auth_screen.dart';
import '../screens/care_plan_detail_screen.dart';
import '../screens/care_plan_review_screen.dart';
import '../screens/care_plan_upload_screen.dart';
import '../screens/care_plans_screen.dart';
import '../screens/care_gap_screens.dart';
import '../screens/dashboard_screen.dart';
import '../screens/family_screens.dart';
import '../screens/landing_screen.dart';
import '../screens/library_screens.dart';
import '../screens/onboarding_screen.dart';
import '../screens/reality_check_screen.dart';
import '../screens/simulation_screen.dart';
import '../screens/support_screens.dart';
import '../data/demo_data.dart';
import '../services/auth_service.dart';
import '../services/care_plan_service.dart';
import 'app_routes.dart';
import 'app_theme.dart';

abstract final class AppRouter {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    var name = settings.name ?? AppRoutes.landing;
    final session = AuthSession.instance;

    if (!AppRoutes.publicRoutes.contains(name) &&
        name != AppRoutes.onboarding &&
        !session.canAccessApp) {
      name = AppRoutes.auth;
    } else if (session.needsOnboarding &&
        name != AppRoutes.onboarding &&
        !AppRoutes.publicRoutes.contains(name)) {
      name = AppRoutes.onboarding;
    } else if (name == AppRoutes.onboarding &&
        (!session.isAuthenticated || !session.needsOnboarding)) {
      name = session.canAccessApp ? AppRoutes.dashboard : AppRoutes.auth;
    }
    final Widget page;
    if (name == AppRoutes.landing) {
      page = const LandingScreen();
    } else if (name == AppRoutes.auth) {
      page = const AuthScreen();
    } else if (name == AppRoutes.onboarding) {
      page = const OnboardingScreen();
    } else if (name == AppRoutes.dashboard) {
      page = const DashboardScreen();
    } else if (name == AppRoutes.carePlans) {
      page = const CarePlansScreen();
    } else if (name == AppRoutes.carePlanNew) {
      page = const NewCarePlanScreen();
    } else if (name == AppRoutes.carePlanUpload) {
      final arguments = settings.arguments;
      page = CarePlanUploadScreen(
        draft: arguments is CarePlanUploadArgs ? arguments : null,
      );
    } else if (name == AppRoutes.carePlanReview) {
      final arguments = settings.arguments;
      final args = arguments is CarePlanReviewArgs ? arguments : null;
      page = CarePlanReviewScreen(
        planId: args?.planId,
        guidedSetup: args?.guidedSetup ?? false,
        returnToPrevious: args?.returnToPrevious ?? false,
      );
    } else if (name == AppRoutes.realityCheck) {
      final arguments = settings.arguments;
      final args = arguments is CareFlowArgs ? arguments : null;
      page = RealityCheckScreen(
        planId: args?.planId,
        guidedSetup: args?.guidedSetup ?? false,
        returnToPrevious: args?.returnToPrevious ?? false,
      );
    } else if (name == AppRoutes.simulation) {
      final arguments = settings.arguments;
      final args = arguments is CareFlowArgs ? arguments : null;
      page = SimulationScreen(
        planId: args?.planId,
        guidedSetup: args?.guidedSetup ?? false,
        returnToPrevious: args?.returnToPrevious ?? false,
      );
    } else if (name == AppRoutes.calendar) {
      page = const CalendarScreen();
    } else if (name == AppRoutes.notifications) {
      page = const NotificationsScreen();
    } else if (name == AppRoutes.documents) {
      page = const DocumentsScreen();
    } else if (name == AppRoutes.progress) {
      page = const ProgressScreen();
    } else if (name == AppRoutes.family) {
      page = const FamilyScreen();
    } else if (name == AppRoutes.familyNew) {
      page = const AddCaregiverScreen();
    } else if (name == AppRoutes.careGaps) {
      final arguments = settings.arguments;
      final args = arguments is CareFlowArgs ? arguments : null;
      page = CareGapsScreen(
        planId: args?.planId,
        guidedSetup: args?.guidedSetup ?? false,
        returnToPrevious: args?.returnToPrevious ?? false,
      );
    } else if (name == AppRoutes.doctorQuestions) {
      page = const DoctorQuestionsScreen();
    } else if (name == AppRoutes.teachBack) {
      page = const TeachBackScreen();
    } else if (name == AppRoutes.simpleCare) {
      page = const SimpleCareScreen();
    } else if (name == AppRoutes.settings) {
      page = const SettingsScreen();
    } else if (name == AppRoutes.patientProfile) {
      page = const PatientProfileScreen();
    } else if (RegExp(r'^/care-plan/[^/]+$').hasMatch(name)) {
      final arguments = settings.arguments;
      final args = arguments is CarePlanDetailArgs ? arguments : null;
      page = CarePlanDetailScreen(
        planId: name.split('/').last,
        initialTab: args?.initialTab ?? (arguments is int ? arguments : 0),
        guidedSetup: args?.guidedSetup ?? false,
        returnToPrevious: args?.returnToPrevious ?? false,
      );
    } else if (RegExp(r'^/care-gaps/[^/]+$').hasMatch(name)) {
      page = CareGapDetailScreen(gapId: name.split('/').last);
    } else if (RegExp(r'^/family/[^/]+$').hasMatch(name)) {
      page = CaregiverDetailScreen(caregiverId: name.split('/').last);
    } else {
      page = const _NotFoundScreen();
    }

    final reduced = CareDemoState.instance.reducedMotion;
    return PageRouteBuilder<void>(
      settings: RouteSettings(name: name, arguments: settings.arguments),
      pageBuilder: (_, animation, secondaryAnimation) => page,
      transitionDuration: Duration(milliseconds: reduced ? 1 : 220),
      reverseTransitionDuration: Duration(milliseconds: reduced ? 1 : 180),
      transitionsBuilder: (_, animation, secondaryAnimation, child) {
        if (reduced) return child;
        final curve = CurvedAnimation(parent: animation, curve: Curves.easeOut);
        return FadeTransition(
          opacity: curve,
          child: AnimatedBuilder(
            animation: curve,
            child: child,
            builder: (context, child) => Transform.translate(offset: Offset(0, 6 * (1 - curve.value)), child: child),
          ),
        );
      },
    );
  }
}

class _NotFoundScreen extends StatelessWidget {
  const _NotFoundScreen();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SehatRoute AI'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('404', style: TextStyle(fontSize: 72, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Page not found', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              const Text("The page you're looking for doesn't exist or has been moved.", textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted)),
              const SizedBox(height: 20),
              FilledButton(onPressed: () => Navigator.pushReplacementNamed(context, AppRoutes.landing), child: const Text('Go home')),
            ],
          ),
        ),
      ),
    );
  }
}
