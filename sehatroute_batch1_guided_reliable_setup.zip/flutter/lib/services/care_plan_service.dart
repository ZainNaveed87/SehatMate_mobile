import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import '../data/demo_data.dart';
import 'auth_service.dart';

class CarePlanException implements Exception {
  const CarePlanException(this.message);

  final String message;

  @override
  String toString() => message;
}

class CarePlanUploadArgs {
  const CarePlanUploadArgs({
    required this.planId,
    required this.documentTypes,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String planId;
  final List<String> documentTypes;
  final bool guidedSetup;
  final bool returnToPrevious;
}

class CarePlanReviewArgs {
  const CarePlanReviewArgs({
    required this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String planId;
  final bool guidedSetup;
  final bool returnToPrevious;
}

class CareFlowArgs {
  const CareFlowArgs({
    required this.planId,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final String planId;
  final bool guidedSetup;
  final bool returnToPrevious;
}

class CarePlanDetailArgs {
  const CarePlanDetailArgs({
    this.initialTab = 0,
    this.guidedSetup = false,
    this.returnToPrevious = false,
  });

  final int initialTab;
  final bool guidedSetup;
  final bool returnToPrevious;
}

enum CareSetupStep {
  upload,
  review,
  schedule,
  realityCheck,
  simulation,
  careGaps,
  activate,
  complete,
}

class CareSetupProgress {
  const CareSetupProgress({
    required this.step,
    required this.title,
    required this.description,
  });

  final CareSetupStep step;
  final String title;
  final String description;

  static const totalSteps = 7;

  int get currentNumber => switch (step) {
        CareSetupStep.upload => 1,
        CareSetupStep.review => 2,
        CareSetupStep.schedule => 3,
        CareSetupStep.realityCheck => 4,
        CareSetupStep.simulation => 5,
        CareSetupStep.careGaps => 6,
        CareSetupStep.activate => 7,
        CareSetupStep.complete => 7,
      };

  int get completedCount =>
      step == CareSetupStep.complete ? totalSteps : currentNumber - 1;
}

class PlanRealityQuestion {
  const PlanRealityQuestion({required this.key, required this.category, required this.question, required this.options, this.selectedAnswer = '', this.note = ''});
  final String key;
  final String category;
  final String question;
  final List<String> options;
  final String selectedAnswer;
  final String note;
}

class CareSimulationData {
  const CareSimulationData({
    required this.readiness,
    required this.blocked,
    required this.atRisk,
    required this.ready,
    required this.unclear,
    required this.tasks,
    required this.findings,
    required this.blockers,
    required this.unanswered,
    required this.activationAllowed,
    required this.hardBlockerCount,
  });

  final int readiness;
  final int blocked;
  final int atRisk;
  final int ready;
  final int unclear;
  final List<DemoTask> tasks;
  final List<Map<String, dynamic>> findings;
  final List<Map<String, dynamic>> blockers;
  final int unanswered;
  final bool activationAllowed;
  final int hardBlockerCount;
}

class CareInstructionReview {
  const CareInstructionReview({
    required this.id,
    required this.category,
    required this.title,
    required this.instruction,
    required this.timing,
    required this.sourcePage,
    required this.confidenceScore,
    required this.reviewStatus,
    required this.requiresProfessionalConfirmation,
    required this.ambiguityReason,
    required this.possibleInterpretation,
    required this.safetyNote,
    required this.safetyCheck,
  });

  final String id;
  final String category;
  final String title;
  final String instruction;
  final String timing;
  final String sourcePage;
  final int? confidenceScore;
  final String reviewStatus;
  final bool requiresProfessionalConfirmation;
  final String ambiguityReason;
  final String possibleInterpretation;
  final String safetyNote;
  final InstructionSafetyCheck? safetyCheck;

  CareInstructionReview copyWith({
    String? title,
    String? instruction,
    String? timing,
    String? reviewStatus,
    bool? requiresProfessionalConfirmation,
    String? ambiguityReason,
    String? possibleInterpretation,
    String? safetyNote,
    InstructionSafetyCheck? safetyCheck,
  }) => CareInstructionReview(
        id: id,
        category: category,
        title: title ?? this.title,
        instruction: instruction ?? this.instruction,
        timing: timing ?? this.timing,
        sourcePage: sourcePage,
        confidenceScore: confidenceScore,
        reviewStatus: reviewStatus ?? this.reviewStatus,
        requiresProfessionalConfirmation: requiresProfessionalConfirmation ?? this.requiresProfessionalConfirmation,
        ambiguityReason: ambiguityReason ?? this.ambiguityReason,
        possibleInterpretation: possibleInterpretation ?? this.possibleInterpretation,
        safetyNote: safetyNote ?? this.safetyNote,
        safetyCheck: safetyCheck ?? this.safetyCheck,
      );
}

class SafetySource {
  const SafetySource({required this.title, required this.url});

  final String title;
  final String url;
}

class InstructionSafetyCheck {
  const InstructionSafetyCheck({
    required this.status,
    required this.summary,
    required this.possibleInterpretation,
    required this.questionForProfessional,
    required this.sources,
  });

  final String status;
  final String summary;
  final String possibleInterpretation;
  final String questionForProfessional;
  final List<SafetySource> sources;
}

class IngredientEvidenceItem {
  const IngredientEvidenceItem({required this.name, required this.strength});

  final String name;
  final String strength;
}

class IngredientEvidence {
  const IngredientEvidence({
    required this.brandName,
    required this.activeIngredients,
    required this.dosageForm,
    required this.manufacturer,
    required this.confidenceScore,
    required this.labelNeedsConfirmation,
    required this.labelNote,
    required this.purposeStatus,
    required this.purposeSummary,
    required this.questionForProfessional,
    required this.sources,
  });

  final String brandName;
  final List<IngredientEvidenceItem> activeIngredients;
  final String dosageForm;
  final String manufacturer;
  final int? confidenceScore;
  final bool labelNeedsConfirmation;
  final String labelNote;
  final String purposeStatus;
  final String purposeSummary;
  final String questionForProfessional;
  final List<SafetySource> sources;
}

class CarePlanDetailData {
  const CarePlanDetailData({
    required this.plan,
    required this.instructions,
    required this.tasks,
    required this.gaps,
    required this.documents,
  });

  final DemoPlan plan;
  final List<DemoTask> instructions;
  final List<DemoTask> tasks;
  final List<DemoGap> gaps;
  final List<DemoDocument> documents;
}


class CareGapSummaryData {
  const CareGapSummaryData({
    required this.total,
    required this.open,
    required this.blocking,
    required this.attention,
    required this.inProgress,
    required this.resolved,
  });

  final int total;
  final int open;
  final int blocking;
  final int attention;
  final int inProgress;
  final int resolved;
}

class CareGapItemData {
  const CareGapItemData({
    required this.id,
    required this.carePlanId,
    required this.taskId,
    required this.category,
    required this.gapType,
    required this.title,
    required this.status,
    required this.severity,
    required this.lifecycleStatus,
    required this.whenText,
    required this.summary,
    required this.instructionSnapshot,
    required this.patientReality,
    required this.reason,
    required this.nextStep,
    required this.resolutionNote,
    required this.sourceKind,
    required this.sourceId,
    required this.dueAt,
    required this.autoManaged,
    required this.blocking,
    required this.actionType,
    required this.actionLabel,
    required this.resolutionTitle,
    required this.resolutionSteps,
    required this.autoRecheck,
    required this.targetCarePlanId,
    required this.targetSourceKind,
    required this.targetSourceId,
    required this.targetCarePlanTab,
    required this.displaySeverity,
    required this.canMarkResolved,
  });

  final String id;
  final String carePlanId;
  final String? taskId;
  final String category;
  final String gapType;
  final String title;
  final String status;
  final String severity;
  final String lifecycleStatus;
  final String whenText;
  final String summary;
  final String instructionSnapshot;
  final String patientReality;
  final String reason;
  final String nextStep;
  final String resolutionNote;
  final String sourceKind;
  final String sourceId;
  final String dueAt;
  final bool autoManaged;
  final bool blocking;
  final String actionType;
  final String actionLabel;
  final String resolutionTitle;
  final List<String> resolutionSteps;
  final bool autoRecheck;
  final String targetCarePlanId;
  final String targetSourceKind;
  final String targetSourceId;
  final int? targetCarePlanTab;
  final String displaySeverity;
  final bool canMarkResolved;

  bool get isResolved => lifecycleStatus == 'resolved';
  bool get isInProgress => lifecycleStatus == 'in_progress';

  TaskStatus get badgeStatus {
    if (isResolved) return TaskStatus.resolved;
    return switch (status) {
      'blocked' => TaskStatus.blocked,
      'unclear' => TaskStatus.unclear,
      'at_risk' => TaskStatus.atRisk,
      _ => severity == 'blocking' ? TaskStatus.blocked : TaskStatus.atRisk,
    };
  }

  String get severityLabel {
    if (displaySeverity == 'previously_blocking' ||
        (isResolved && severity == 'blocking')) {
      return 'Previously blocking';
    }
    return severity == 'blocking' ? 'Blocking' : 'Needs attention';
  }

  bool get severityWasBlocking => severity == 'blocking';

  String get lifecycleLabel => switch (lifecycleStatus) {
        'in_progress' => 'In progress',
        'resolved' => 'Resolved',
        _ => 'Open',
      };

  String get typeLabel => switch (gapType) {
        'missing_information' => 'Missing information',
        'schedule_gap' => 'Schedule gap',
        'overdue' => 'Overdue',
        'verification' => 'Verification',
        'document_gap' => 'Document gap',
        'care_coordination' => 'Care coordination',
        _ => category.isEmpty ? 'Care gap' : category,
      };
}

class CareGapDoctorQuestionData {
  const CareGapDoctorQuestionData({
    required this.id,
    required this.groupName,
    required this.title,
    required this.question,
    required this.answer,
    required this.status,
  });

  final String id;
  final String groupName;
  final String title;
  final String question;
  final String answer;
  final String status;

  bool get answered => status == 'answered';
}

class CareGapListData {
  const CareGapListData({required this.summary, required this.gaps});

  final CareGapSummaryData summary;
  final List<CareGapItemData> gaps;
}

class CareGapDetailData {
  const CareGapDetailData({
    required this.gap,
    required this.doctorQuestions,
  });

  final CareGapItemData gap;
  final List<CareGapDoctorQuestionData> doctorQuestions;
}

class CarePlanService {
  CarePlanService._();

  static final CarePlanService instance = CarePlanService._();
  static const _timeout = Duration(seconds: 20);

  final http.Client _client = http.Client();

  CareSetupProgress _progressForStep(CareSetupStep step) => switch (step) {
        CareSetupStep.upload => const CareSetupProgress(
            step: CareSetupStep.upload,
            title: 'Upload & extract documents',
            description: 'Add the source documents and extract their instructions.',
          ),
        CareSetupStep.review => const CareSetupProgress(
            step: CareSetupStep.review,
            title: 'Review extracted instructions',
            description: 'Check every extracted instruction against the original document.',
          ),
        CareSetupStep.schedule => const CareSetupProgress(
            step: CareSetupStep.schedule,
            title: 'Finish schedule setup',
            description: 'Confirm every required reminder period and exact time.',
          ),
        CareSetupStep.realityCheck => const CareSetupProgress(
            step: CareSetupStep.realityCheck,
            title: 'Continue Reality Check',
            description: 'Answer the remaining practical routine questions.',
          ),
        CareSetupStep.simulation => const CareSetupProgress(
            step: CareSetupStep.simulation,
            title: 'Review simulation',
            description: 'Review practical fit and SehatRoute suggestions.',
          ),
        CareSetupStep.careGaps => const CareSetupProgress(
            step: CareSetupStep.careGaps,
            title: 'Review Care Gaps',
            description: 'Resolve only the required blockers before the final simulation.',
          ),
        CareSetupStep.activate => const CareSetupProgress(
            step: CareSetupStep.activate,
            title: 'Final review & activation',
            description: 'Review the updated simulation and activate the care plan.',
          ),
        CareSetupStep.complete => const CareSetupProgress(
            step: CareSetupStep.complete,
            title: 'Open care plan',
            description: 'This care plan has finished setup.',
          ),
      };

  CareSetupStep _setupStepFromApi(Object? value) => switch (_displayText(value)) {
        'upload' => CareSetupStep.upload,
        'review' => CareSetupStep.review,
        'schedule' => CareSetupStep.schedule,
        'reality_check' => CareSetupStep.realityCheck,
        'simulation' => CareSetupStep.simulation,
        'care_gaps' => CareSetupStep.careGaps,
        'activate' => CareSetupStep.activate,
        'complete' => CareSetupStep.complete,
        _ => CareSetupStep.upload,
      };

  String _setupStepApiValue(CareSetupStep step) => switch (step) {
        CareSetupStep.upload => 'upload',
        CareSetupStep.review => 'review',
        CareSetupStep.schedule => 'schedule',
        CareSetupStep.realityCheck => 'reality_check',
        CareSetupStep.simulation => 'simulation',
        CareSetupStep.careGaps => 'care_gaps',
        CareSetupStep.activate => 'activate',
        CareSetupStep.complete => 'complete',
      };

  Future<CareSetupProgress> fetchSetupProgress(String planId) async {
    final data = await _request('GET', '/care-plans/$planId/setup-progress');
    return _progressForStep(_setupStepFromApi(data['step']));
  }

  Future<void> updateSetupStep(String planId, CareSetupStep step) async {
    await _request(
      'PATCH',
      '/care-plans/$planId/setup-progress',
      body: {'step': _setupStepApiValue(step)},
    );
  }

  Future<CareSetupProgress> resolveSetupProgress(DemoPlan plan) async {
    if (plan.status == PlanStatus.active || plan.status == PlanStatus.completed) {
      return _progressForStep(CareSetupStep.complete);
    }

    try {
      return await fetchSetupProgress(plan.id);
    } on CarePlanException {
      // Compatibility fallback for a backend that has not been restarted yet.
    }

    if (plan.status == PlanStatus.draft || plan.status == PlanStatus.processing) {
      return _progressForStep(CareSetupStep.upload);
    }
    if (plan.status == PlanStatus.needsReview) {
      return _progressForStep(CareSetupStep.review);
    }

    final detail = await fetchPlanDetail(plan.id);
    if (detail.tasks.isEmpty ||
        detail.tasks.any(
          (task) =>
              task.status == TaskStatus.atRisk ||
              task.status == TaskStatus.unclear,
        )) {
      return _progressForStep(CareSetupStep.schedule);
    }

    try {
      final questions = await fetchRealityQuestions(plan.id);
      if (questions.any((question) => question.selectedAnswer.isEmpty)) {
        return _progressForStep(CareSetupStep.realityCheck);
      }
    } on CarePlanException {
      return _progressForStep(CareSetupStep.schedule);
    }

    return _progressForStep(CareSetupStep.simulation);
  }

  Future<List<DemoPlan>> fetchPlans() async {
    final data = await _request('GET', '/care-plans');
    final plans = data['plans'];
    if (plans is! List) {
      throw const CarePlanException('The server returned an invalid plan list.');
    }

    return plans
        .whereType<Map<String, dynamic>>()
        .map(_planFromJson)
        .toList();
  }

  Future<DemoPlan> createPlan(String title) async {
    final data = await _request(
      'POST',
      '/care-plans',
      body: {'title': title.trim()},
    );
    final plan = data['plan'];
    if (plan is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid care plan.');
    }
    return _planFromJson(plan);
  }

  Future<void> deletePlan(String planId) async {
    await _request('DELETE', '/care-plans/$planId');
  }

  Future<void> deletePlans(List<String> planIds) async {
    await _request('POST', '/care-plans/bulk-delete', body: {'planIds': planIds});
  }

  Future<void> savePlanDuration(String planId, {required String mode, String? endDate}) async {
    await _request('PATCH', '/care-plans/$planId/duration', body: {
      'mode': mode,
      'endDate': endDate,
    });
  }

  Future<void> completePlan(String planId) async {
    await _request('PATCH', '/care-plans/$planId/status', body: const {'status': 'completed'});
  }

  Future<CarePlanDetailData> fetchPlanDetail(String planId) async {
    final data = await _request('GET', '/care-plans/$planId');
    final planJson = data['plan'];
    if (planJson is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid care plan.');
    }

    final plan = _planFromJson(planJson);
    final instructions = _listOfMaps(
      data.containsKey('verifiedInstructions')
          ? data['verifiedInstructions']
          : data['instructions'],
    )
        .map(_instructionFromJson)
        .toList();
    final tasks = _listOfMaps(data['tasks']).map(_taskFromJson).toList();
    final gaps = _listOfMaps(data['gaps']).map(_gapFromJson).toList();
    final documents = _listOfMaps(data['documents'])
        .map((item) => _documentFromJson(item, plan.title))
        .toList();

    return CarePlanDetailData(
      plan: plan,
      instructions: instructions,
      tasks: tasks,
      gaps: gaps,
      documents: documents,
    );
  }

  Future<String> uploadDocument({
    required String planId,
    required String documentType,
    required String originalName,
    required String mimeType,
    required List<int> bytes,
  }) async {
    if (bytes.isEmpty || bytes.length > 20 * 1024 * 1024) {
      throw const CarePlanException(
        'The document is empty or exceeds the 20 MB limit.',
      );
    }
    final data = await _request(
      'POST',
      '/care-plans/$planId/documents',
      body: {
        'documentType': documentType,
        'originalName': originalName,
        'mimeType': mimeType,
        'contentBase64': base64Encode(bytes),
      },
    );
    final document = data['document'];
    if (document is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid document.');
    }
    final documentId = document['id']?.toString() ?? '';
    if (documentId.isEmpty) {
      throw const CarePlanException('The server did not return a document ID.');
    }
    return documentId;
  }

  Future<void> deleteDocument(String documentId) async {
    await _request('DELETE', '/documents/$documentId');
  }

  Future<int> extractInstructions(String planId) async {
    final data = await _request(
      'POST',
      '/care-plans/$planId/extract',
      timeout: const Duration(minutes: 3),
    );
    return _integer(data['instructionCount']);
  }

  Future<List<CareInstructionReview>> fetchReviewInstructions(
    String planId,
  ) async {
    final data = await _request('GET', '/care-plans/$planId');
    return _listOfMaps(data['instructions'])
        .map(
          (json) {
            final category = _displayText(json['category']);
            final reviewStatus = _displayText(json['review_status']);
            return CareInstructionReview(
              id: _displayText(json['id']),
              category: category.isEmpty ? 'other' : category,
              title: _displayText(json['title']),
              instruction: _displayText(json['instruction']),
              timing: _displayText(json['timing']),
              sourcePage: _displayText(json['source_page']),
              confidenceScore: json['confidence_score'] == null
                  ? null
                  : _integer(json['confidence_score']).clamp(0, 100).toInt(),
              reviewStatus: reviewStatus.isEmpty ? 'pending' : reviewStatus,
              requiresProfessionalConfirmation: _boolean(json['requires_professional_confirmation']),
              ambiguityReason: _displayText(json['ambiguity_reason']),
              possibleInterpretation: _displayText(json['possible_interpretation']),
              safetyNote: _displayText(json['safety_note']),
              safetyCheck: _safetyCheckFromInstruction(json),
            );
          },
        )
        .where(
          (item) =>
              item.id.isNotEmpty &&
              item.title.trim().isNotEmpty &&
              item.instruction.trim().isNotEmpty,
        )
        .toList();
  }

  Future<void> reviewInstruction({
    required String instructionId,
    required String title,
    required String instruction,
    required String timing,
    required String reviewStatus,
  }) async {
    await _request(
      'PATCH',
      '/instructions/$instructionId',
      body: {
        'title': title.trim(),
        'instruction': instruction.trim(),
        'timing': timing.trim(),
        'reviewStatus': reviewStatus,
      },
    );
  }

  Future<InstructionSafetyCheck> checkInstructionSafety(String instructionId) async {
    final data = await _request(
      'POST',
      '/instructions/$instructionId/safety-check',
      timeout: const Duration(minutes: 2),
    );
    final check = data['safetyCheck'];
    if (check is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid safety check.');
    }
    return _safetyCheckFromJson(check);
  }

  Future<IngredientEvidence> analyzeIngredientEvidence({
    required String instructionId,
    required String originalName,
    required String mimeType,
    required List<int> bytes,
  }) async {
    if (bytes.isEmpty || bytes.length > 10 * 1024 * 1024) {
      throw const CarePlanException('The label image is empty or exceeds the 10 MB limit.');
    }
    final data = await _request(
      'POST',
      '/instructions/$instructionId/ingredient-evidence',
      body: {
        'originalName': originalName,
        'mimeType': mimeType,
        'contentBase64': base64Encode(bytes),
      },
      timeout: const Duration(minutes: 3),
    );
    final evidence = data['evidence'];
    if (evidence is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned invalid ingredient evidence.');
    }
    final confidence = evidence['confidenceScore'];
    return IngredientEvidence(
      brandName: _displayText(evidence['brandName']),
      activeIngredients: _listOfMaps(evidence['activeIngredients'])
          .map((item) => IngredientEvidenceItem(
                name: _displayText(item['name']),
                strength: _displayText(item['strength']),
              ))
          .where((item) => item.name.isNotEmpty)
          .toList(),
      dosageForm: _displayText(evidence['dosageForm']),
      manufacturer: _displayText(evidence['manufacturer']),
      confidenceScore: confidence == null
          ? null
          : _integer(confidence).clamp(0, 100).toInt(),
      labelNeedsConfirmation: _boolean(evidence['labelNeedsConfirmation']),
      labelNote: _displayText(evidence['labelNote']),
      purposeStatus: _displayText(evidence['purposeStatus']),
      purposeSummary: _displayText(evidence['purposeSummary']),
      questionForProfessional: _displayText(evidence['questionForProfessional']),
      sources: _listOfMaps(evidence['sources'])
          .map((item) => SafetySource(
                title: _displayText(item['title']).isEmpty
                    ? 'Trusted health source'
                    : _displayText(item['title']),
                url: _displayText(item['url']),
              ))
          .where((source) => source.url.isNotEmpty)
          .toList(),
    );
  }

  Future<void> finalizeReview(String planId) async {
    await _request('POST', '/care-plans/$planId/finalize-review');
  }

  Future<void> generateSchedule(String planId) async {
    await _request(
      'POST',
      '/care-plans/$planId/generate-schedule',
      timeout: const Duration(minutes: 2),
    );
  }

  Future<void> confirmScheduleItem(
    String itemId, {
    required String scheduleTime,
    String displayTime = '',
  }) async {
    await _request(
      'PATCH',
      '/schedule-items/$itemId/confirm',
      body: {
        'scheduleTime': scheduleTime.trim(),
        'displayTime': displayTime.trim(),
      },
    );
  }

  Future<List<PlanRealityQuestion>> fetchRealityQuestions(String planId) async {
    final data = await _request('GET', '/care-plans/$planId/reality-check');
    return _listOfMaps(data['questions']).map((item) => PlanRealityQuestion(
      key: _displayText(item['key']),
      category: _displayText(item['category']),
      question: _displayText(item['question']),
      options: item['options'] is List ? (item['options'] as List).map(_displayText).where((value) => value.isNotEmpty).toList() : const [],
      selectedAnswer: _displayText(item['selectedAnswer']),
      note: _displayText(item['note']),
    )).where((item) => item.key.isNotEmpty && item.options.isNotEmpty).toList();
  }

  Future<void> saveRealityAnswers(String planId, List<Map<String, String>> answers) async {
    await _request('POST', '/care-plans/$planId/reality-check', body: {'answers': answers});
  }

  Future<CareSimulationData> fetchSimulation(String planId) async {
    final data = await _request('GET', '/care-plans/$planId/simulation');
    final metrics = data['metrics'] is Map<String, dynamic> ? data['metrics'] as Map<String, dynamic> : <String, dynamic>{};
    return CareSimulationData(
      readiness: _integer(data['readiness']).clamp(0, 100).toInt(),
      blocked: _integer(metrics['blocked']),
      atRisk: _integer(metrics['atRisk']),
      ready: _integer(metrics['ready']),
      unclear: _integer(metrics['unclear']),
      tasks: _listOfMaps(data['tasks']).map((item) => DemoTask(
        id: _displayText(item['id']),
        day: _displayText(item['schedule_date']),
        time: _displayText(item['schedule_time']).isNotEmpty ? _displayText(item['schedule_time']) : (_displayText(item['display_time']).isNotEmpty ? _displayText(item['display_time']) : 'Review timing'),
        title: _displayText(item['title']),
        note: [_displayText(item['recurrence_text']), _displayText(item['reason'])].where((value) => value.isNotEmpty).join(' · '),
        kind: _taskKind(_displayText(item['task_kind'])),
        status: _taskStatus(_displayText(item['status'])),
      )).toList(),
      findings: _listOfMaps(data['findings']),
      blockers: _listOfMaps(data['blockers']),
      unanswered: _integer(data['unanswered']),
      activationAllowed: data['activationAllowed'] == true,
      hardBlockerCount: _integer(data['hardBlockerCount']),
    );
  }

  Future<CareGapListData> fetchCareGaps(String planId) async {
    final data = await _request('GET', '/care-plans/$planId/care-gaps');
    return CareGapListData(
      summary: _careGapSummaryFromJson(
        data['summary'] is Map<String, dynamic>
            ? data['summary'] as Map<String, dynamic>
            : const <String, dynamic>{},
      ),
      gaps: _listOfMaps(data['gaps']).map(_careGapItemFromJson).toList(),
    );
  }

  Future<CareGapListData> refreshCareGaps(String planId) async {
    final data = await _request('POST', '/care-plans/$planId/care-gaps/refresh');
    return CareGapListData(
      summary: _careGapSummaryFromJson(
        data['summary'] is Map<String, dynamic>
            ? data['summary'] as Map<String, dynamic>
            : const <String, dynamic>{},
      ),
      gaps: _listOfMaps(data['gaps']).map(_careGapItemFromJson).toList(),
    );
  }

  Future<CareGapDetailData> fetchCareGap(String gapId) async {
    final data = await _request('GET', '/care-gaps/$gapId');
    final gap = data['gap'];
    if (gap is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid care gap.');
    }

    return CareGapDetailData(
      gap: _careGapItemFromJson(gap),
      doctorQuestions: _listOfMaps(data['doctorQuestions'])
          .map(_careGapDoctorQuestionFromJson)
          .toList(),
    );
  }

  Future<CareGapItemData> updateCareGap(
    String gapId, {
    required String lifecycleStatus,
    String resolutionNote = '',
  }) async {
    final data = await _request(
      'PATCH',
      '/care-gaps/$gapId',
      body: {
        'lifecycleStatus': lifecycleStatus,
        'resolutionNote': resolutionNote.trim(),
      },
    );
    final gap = data['gap'];
    if (gap is! Map<String, dynamic>) {
      throw const CarePlanException('The server returned an invalid care gap.');
    }
    return _careGapItemFromJson(gap);
  }

  Future<String> createCareGapDoctorQuestion(
    String gapId, {
    required String groupName,
    required String title,
    required String question,
  }) async {
    final data = await _request(
      'POST',
      '/care-gaps/$gapId/doctor-question',
      body: {
        'groupName': groupName.trim(),
        'title': title.trim(),
        'question': question.trim(),
      },
    );
    return _displayText(data['questionId']);
  }

  Future<CarePlanDetailData> activatePlan(String planId) async {
    await _request(
      'PATCH',
      '/care-plans/$planId/status',
      body: const {'status': 'active'},
    );
    return fetchPlanDetail(planId);
  }

  List<Map<String, dynamic>> _listOfMaps(dynamic value) {
    if (value is! List) return const [];
    return value.whereType<Map<String, dynamic>>().toList();
  }

  bool _boolean(dynamic value) => value == true || value == 1 || value == '1';

  String _displayText(dynamic value) => value
      ?.toString()
      .replaceAll(RegExp(r'[\u0000-\u001F\u007F\u200B-\u200D\u2060\uFEFF]'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim() ?? '';

  InstructionSafetyCheck? _safetyCheckFromInstruction(Map<String, dynamic> json) {
    final rawStatus = _displayText(json['safety_check_status']);
    final status = rawStatus.isEmpty ? 'not_checked' : rawStatus;
    if (status == 'not_checked') return null;
    return InstructionSafetyCheck(
      status: status,
      summary: _displayText(json['safety_check_summary']),
      possibleInterpretation: _displayText(json['safety_possible_interpretation']),
      questionForProfessional: _displayText(json['safety_question']),
      sources: _listOfMaps(json['safety_sources'])
          .map((item) => SafetySource(
                title: _displayText(item['title']).isEmpty
                    ? 'Trusted health source'
                    : _displayText(item['title']),
                url: _displayText(item['url']),
              ))
          .where((source) => source.url.isNotEmpty)
          .toList(),
    );
  }

  InstructionSafetyCheck _safetyCheckFromJson(Map<String, dynamic> json) {
    return InstructionSafetyCheck(
      status: _displayText(json['status']).isEmpty
          ? 'source_not_found'
          : _displayText(json['status']),
      summary: _displayText(json['summary']),
      possibleInterpretation: _displayText(json['possibleInterpretation']),
      questionForProfessional: _displayText(json['questionForProfessional']),
      sources: _listOfMaps(json['sources'])
          .map((item) => SafetySource(
                title: _displayText(item['title']).isEmpty
                    ? 'Trusted health source'
                    : _displayText(item['title']),
                url: _displayText(item['url']),
              ))
          .where((source) => source.url.isNotEmpty)
          .toList(),
    );
  }

  DemoPlan _planFromJson(Map<String, dynamic> json) {
    final status = _planStatus(json['status']?.toString());
    final startDate = _displayDate(
      json['startDate'] ?? json['createdAt'],
      fallback: status == PlanStatus.draft ? 'Not started' : 'Recently',
    );
    return DemoPlan(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Care Plan',
      status: status,
      startDate: startDate,
      readiness: _integer(json['readinessScore']).clamp(0, 100).toInt(),
      nextTask: _nextStep(status),
      documents: const [],
      durationMode: _displayText(json['durationMode']).isEmpty ? 'prescription' : _displayText(json['durationMode']),
      suggestedEndDate: _displayText(json['suggestedEndDate']),
      plannedEndDate: _displayText(json['plannedEndDate']),
    );
  }

  DemoTask _instructionFromJson(Map<String, dynamic> json) {
    final reviewStatus = json['review_status']?.toString();
    return DemoTask(
      id: json['id']?.toString() ?? '',
      day: '',
      time: json['timing']?.toString() ?? 'Timing not set',
      title: json['title']?.toString() ?? 'Care instruction',
      note: json['instruction']?.toString() ?? '',
      kind: _taskKind(json['category']?.toString()),
      status: reviewStatus == 'verified'
          ? TaskStatus.ready
          : reviewStatus == 'unclear'
              ? TaskStatus.unclear
              : TaskStatus.atRisk,
    );
  }

  DemoTask _taskFromJson(Map<String, dynamic> json) {
    return DemoTask(
      id: json['id']?.toString() ?? '',
      day: json['task_date']?.toString() ?? '',
      time: json['task_time']?.toString() ?? 'Time not set',
      title: json['title']?.toString() ?? 'Care task',
      note: json['note']?.toString() ?? '',
      kind: _taskKind(json['task_kind']?.toString()),
      status: _taskStatus(json['status']?.toString()),
      completed: json['status']?.toString() == 'completed',
      caregiverId: json['caregiver_id']?.toString(),
    );
  }

  CareGapSummaryData _careGapSummaryFromJson(Map<String, dynamic> json) {
    return CareGapSummaryData(
      total: _integer(json['total']),
      open: _integer(json['open']),
      blocking: _integer(json['blocking']),
      attention: _integer(json['attention']),
      inProgress: _integer(json['inProgress']),
      resolved: _integer(json['resolved']),
    );
  }

  CareGapItemData _careGapItemFromJson(Map<String, dynamic> json) {
    final target = json['target'] is Map<String, dynamic>
        ? json['target'] as Map<String, dynamic>
        : const <String, dynamic>{};
    final targetTabRaw = target['care_plan_tab'];
    final targetTab = targetTabRaw == null
        ? null
        : int.tryParse(targetTabRaw.toString());
    final resolutionSteps = json['resolution_steps'] is List
        ? (json['resolution_steps'] as List)
            .map(_displayText)
            .where((step) => step.isNotEmpty)
            .toList()
        : const <String>[];

    final carePlanId = _displayText(json['care_plan_id']);
    final sourceKind = _displayText(json['source_kind']);
    final sourceId = _displayText(json['source_id']);

    return CareGapItemData(
      id: _displayText(json['id']),
      carePlanId: carePlanId,
      taskId: _displayText(json['task_id']).isEmpty
          ? null
          : _displayText(json['task_id']),
      category: _displayText(json['category']),
      gapType: _displayText(json['gap_type']),
      title: _displayText(json['title']).isEmpty
          ? 'Care gap'
          : _displayText(json['title']),
      status: _displayText(json['status']),
      severity: _displayText(json['severity']).isEmpty
          ? 'attention'
          : _displayText(json['severity']),
      lifecycleStatus: _displayText(json['lifecycle_status']).isEmpty
          ? (_displayText(json['status']) == 'resolved' ? 'resolved' : 'open')
          : _displayText(json['lifecycle_status']),
      whenText: _displayText(json['when_text']),
      summary: _displayText(json['summary']),
      instructionSnapshot: _displayText(json['instruction_snapshot']),
      patientReality: _displayText(json['patient_reality']),
      reason: _displayText(json['reason']),
      nextStep: _displayText(json['next_step']),
      resolutionNote: _displayText(json['resolution_note']),
      sourceKind: sourceKind,
      sourceId: sourceId,
      dueAt: _displayText(json['due_at']),
      autoManaged: _boolean(json['auto_managed']),
      blocking: _boolean(json['blocking']),
      actionType: _displayText(json['action_type']),
      actionLabel: _displayText(json['action_label']).isEmpty
          ? 'Review care plan'
          : _displayText(json['action_label']),
      resolutionTitle: _displayText(json['resolution_title']).isEmpty
          ? 'How to resolve this gap'
          : _displayText(json['resolution_title']),
      resolutionSteps: resolutionSteps,
      autoRecheck: json.containsKey('auto_recheck')
          ? _boolean(json['auto_recheck'])
          : _boolean(json['auto_managed']),
      targetCarePlanId: _displayText(target['care_plan_id']).isEmpty
          ? carePlanId
          : _displayText(target['care_plan_id']),
      targetSourceKind: _displayText(target['source_kind']).isEmpty
          ? sourceKind
          : _displayText(target['source_kind']),
      targetSourceId: _displayText(target['source_id']).isEmpty
          ? sourceId
          : _displayText(target['source_id']),
      targetCarePlanTab: targetTab,
      displaySeverity: _displayText(json['display_severity']),
      canMarkResolved: json.containsKey('can_mark_resolved')
          ? _boolean(json['can_mark_resolved'])
          : !_boolean(json['auto_managed']),
    );
  }

  CareGapDoctorQuestionData _careGapDoctorQuestionFromJson(Map<String, dynamic> json) {
    return CareGapDoctorQuestionData(
      id: _displayText(json['id']),
      groupName: _displayText(json['group_name']),
      title: _displayText(json['title']),
      question: _displayText(json['question']),
      answer: _displayText(json['answer']),
      status: _displayText(json['status']),
    );
  }

  DemoGap _gapFromJson(Map<String, dynamic> json) {
    return DemoGap(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Care gap',
      status: _taskStatus(json['status']?.toString()),
      category: json['category']?.toString() ?? 'Care plan',
      when: json['when_text']?.toString() ?? '',
      summary: json['summary']?.toString() ?? '',
      instruction: json['instruction_snapshot']?.toString() ?? '',
      reality: json['patient_reality']?.toString() ?? '',
      reason: json['reason']?.toString() ?? '',
      nextStep: json['next_step']?.toString() ?? '',
      taskId: json['task_id']?.toString(),
    );
  }

  DemoDocument _documentFromJson(
    Map<String, dynamic> json,
    String planTitle,
  ) {
    final originalName = json['original_name']?.toString() ?? 'Document';
    final extension = originalName.contains('.')
        ? originalName.split('.').last.toUpperCase()
        : 'FILE';
    return DemoDocument(
      id: json['id']?.toString() ?? '',
      name: originalName,
      type: extension,
      date: _displayDate(json['created_at'], fallback: 'Recently'),
      pages: _integer(json['page_count']).clamp(0, 9999).toInt(),
      plan: planTitle,
    );
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    Duration timeout = _timeout,
  }) async {
    final token = AuthSession.instance.token;
    if (token == null || token.isEmpty) {
      throw const CarePlanException('Please sign in to continue.');
    }

    try {
      final headers = <String, String>{
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': 'Bearer $token',
      };
      final uri = ApiConfig.endpoint(path);
      late final http.Response response;
      if (method == 'POST') {
        response = await _client
            .post(uri, headers: headers, body: jsonEncode(body ?? const <String, dynamic>{}))
            .timeout(timeout);
      } else if (method == 'PATCH') {
        response = await _client
            .patch(uri, headers: headers, body: jsonEncode(body ?? const <String, dynamic>{}))
            .timeout(timeout);
      } else if (method == 'DELETE') {
        response = await _client.delete(uri, headers: headers).timeout(timeout);
      } else {
        response = await _client.get(uri, headers: headers).timeout(timeout);
      }

      final decoded = _decode(response);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw CarePlanException(
          decoded['message']?.toString() ??
              'The care plan request could not be completed.',
        );
      }
      final data = decoded['data'];
      if (data is! Map<String, dynamic>) {
        throw const CarePlanException('The server returned an invalid response.');
      }
      return data;
    } on TimeoutException {
      throw const CarePlanException(
        'The server took too long to respond. Please try again.',
      );
    } on http.ClientException {
      throw const CarePlanException(
        'Could not connect to the server. Check your internet connection.',
      );
    } on FormatException {
      throw const CarePlanException('The server returned an invalid response.');
    }
  }

  Map<String, dynamic> _decode(http.Response response) {
    if (response.bodyBytes.isEmpty) return <String, dynamic>{};
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is Map<String, dynamic>) return decoded;
    throw const FormatException('Expected a JSON object.');
  }

  int _integer(dynamic value) {
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? 0;
  }

  PlanStatus _planStatus(String? value) => switch (value) {
        'processing' => PlanStatus.processing,
        'needs_review' => PlanStatus.needsReview,
        'reality_check' => PlanStatus.realityCheck,
        'needs_attention' => PlanStatus.needsAttention,
        'active' => PlanStatus.active,
        'completed' => PlanStatus.completed,
        _ => PlanStatus.draft,
      };

  TaskStatus _taskStatus(String? value) => switch (value) {
        'ready' => TaskStatus.ready,
        'pending' => TaskStatus.ready,
        'at_risk' => TaskStatus.atRisk,
        'blocked' => TaskStatus.blocked,
        'open' => TaskStatus.blocked,
        'unclear' => TaskStatus.unclear,
        'resolved' => TaskStatus.resolved,
        'completed' => TaskStatus.resolved,
        _ => TaskStatus.ready,
      };

  TaskKind _taskKind(String? value) {
    final normalized = value?.toLowerCase() ?? '';
    if (normalized.contains('lab') || normalized.contains('test')) {
      return TaskKind.lab;
    }
    if (normalized.contains('visit') || normalized.contains('follow')) {
      return TaskKind.visit;
    }
    if (normalized.contains('dress') || normalized.contains('wound')) {
      return TaskKind.dressing;
    }
    if (normalized.contains('caregiver') || normalized.contains('support')) {
      return TaskKind.caregiver;
    }
    return TaskKind.medicine;
  }

  String _nextStep(PlanStatus status) => switch (status) {
        PlanStatus.draft => 'Upload documents to continue',
        PlanStatus.processing => 'Documents are being processed',
        PlanStatus.needsReview => 'Review extracted instructions',
        PlanStatus.realityCheck => 'Complete the reality check',
        PlanStatus.needsAttention => 'Resolve open care gaps',
        PlanStatus.active => 'Open the schedule for the next task',
        PlanStatus.completed => 'Plan completed',
      };

  String _displayDate(dynamic value, {required String fallback}) {
    final parsed = DateTime.tryParse(value?.toString() ?? '');
    if (parsed == null) return fallback;
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${parsed.day.toString().padLeft(2, '0')} '
        '${months[parsed.month - 1]} ${parsed.year}';
  }
}
